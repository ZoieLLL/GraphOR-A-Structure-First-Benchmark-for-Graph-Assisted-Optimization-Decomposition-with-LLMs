
from __future__ import annotations

import json
from textwrap import dedent
from typing import List, Dict, Any, Optional

from utils.data_models import StructureBlueprint, GeneratedProblem
from utils.validation import verify_structure, compare_with_blueprint
from utils.llm_client import BaseLLMClient
from utils.prompt_utils import normalize_json_response
from utils.math_validator import check_math_feasibility, DEFAULT_TIME_LIMIT


class VerifierAgent:
    def __init__(
        self,
        llm_client: Optional[BaseLLMClient] = None,
        system_prompt: str | None = None,
        math_time_limit: float = DEFAULT_TIME_LIMIT,
    ):
        self.failures: List[Dict[str, Any]] = []
        self.llm_client = llm_client
        self.system_prompt = system_prompt or (
            "You explain whether generated problems match their structural blueprints."
        )
        self.math_time_limit = math_time_limit

    def run(self, blueprints: List[StructureBlueprint], problems: List[GeneratedProblem]) -> List[GeneratedProblem]:
        blueprint_map = {bp.name: bp for bp in blueprints}
        verified: List[GeneratedProblem] = []
        for problem in problems:
            try:
                ok = self._verify_one(blueprint_map, problem, verified)
                if not ok:
                    pass 
            except Exception as exc:
                print(f"[verifier] skipping problem '{problem.meta.get('source_blueprint')}': {exc}")
                self.failures.append({
                    "problem": problem.meta.get("source_blueprint"),
                    "reason": f"unexpected error: {exc}",
                })
        return verified

    def _verify_one(
        self,
        blueprint_map: Dict[str, Any],
        problem: GeneratedProblem,
        verified: List[GeneratedProblem],
    ) -> bool:
        blueprint = blueprint_map.get(problem.meta.get("source_blueprint"))
        if not blueprint:
            self.failures.append({
                "problem": problem.meta.get("source_blueprint"),
                "reason": "missing blueprint",
            })
            return False

        base_ok, base_errors = verify_structure(problem)
        align_ok, align_errors = compare_with_blueprint(
            blueprint.to_prompt_dict(), problem)

        math_result = check_math_feasibility(
            problem.to_dict(), time_limit=self.math_time_limit)
        math_status = math_result["status"]
        problem.meta["math_validation"] = math_result

        math_hard_fail = math_status in ("INFEASIBLE", "UNBOUNDED")

        verdict_text = self._llm_feedback(
            blueprint, problem, base_ok and align_ok and not math_hard_fail)

        if base_ok and align_ok and not math_hard_fail:
            if verdict_text:
                problem.meta.setdefault("verifier_comment", verdict_text)
            verified.append(problem)
            return True
        else:
            failure_record = {
                "problem": blueprint.name,
                "errors": base_errors + align_errors,
            }
            if math_hard_fail:
                failure_record["math_validation"] = (
                    f"{math_status}: {math_result.get('hint', '')}")
            if verdict_text:
                failure_record["llm_feedback"] = verdict_text
            self.failures.append(failure_record)
            return False

    def report(self) -> Dict[str, Any]:
        return {
            "total_failures": len(self.failures),
            "details": self.failures,
        }

    def _llm_feedback(
        self,
        blueprint: StructureBlueprint,
        problem: GeneratedProblem,
        passed: bool,
    ) -> str:
        if not self.llm_client:
            return ""
        status = "PASS" if passed else "FAIL"
        prompt = dedent(
            """
            Blueprint vs problem verification status: {status}.
            Blueprint summary: variables={variables}, constraints={constraints}.
            Generated question: {question}.
            Respond with EXACTLY one JSON object formatted as {{"verdict": string, "explanation": string, "action": string}}.
            Use double quotes, keep the verdict as PASS/FAIL, and provide concise sentences.
            Do not include markdown code fences or additional commentary.
            Example output: {{"verdict": "FAIL", "explanation": "c2 missing the shared warehouse flow", "action": "Add coupling term for c2"}}.
            Please follow that structure exactly.
            """
        ).format(
            status=status,
            variables=blueprint.structure.variables,
            constraints=blueprint.structure.constraints,
            question=problem.question,
        )
        try:
            response = self.llm_client.generate(
                prompt, system_prompt=self.system_prompt)
            cleaned = normalize_json_response(response)
            data = json.loads(cleaned)
            verdict = str(data.get("verdict", status)).strip().upper()
            explanation = str(data.get("explanation", "")).strip()
            action = str(data.get("action", "")).strip()
            parts = [verdict]
            if explanation:
                parts.append(explanation)
            if action:
                parts.append(f"Next: {action}")
            return " | ".join(parts)
        except json.JSONDecodeError:
            return response.strip()
        except Exception:  
            return ""
