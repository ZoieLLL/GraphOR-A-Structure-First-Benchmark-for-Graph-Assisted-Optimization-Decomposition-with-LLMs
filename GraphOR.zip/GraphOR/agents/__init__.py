"""Agent module initialization for GraphOR pipeline."""
