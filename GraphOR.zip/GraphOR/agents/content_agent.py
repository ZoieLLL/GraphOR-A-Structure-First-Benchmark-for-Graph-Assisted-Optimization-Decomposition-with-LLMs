
from __future__ import annotations

import json
import random
import re
from typing import Dict, List, Tuple

from prompts.content_templates import (
    MATHEMATICAL_BRIEF_TEMPLATE,
    QUESTION_BRIEF_TEMPLATE,
    format_blueprint_summary,
    format_constraint_summary,
)
from utils.data_models import (
    GeneratedProblem,
    ProblemStructure,
    StructureBlueprint,
)
from utils.llm_client import BaseLLMClient, MockLLMClient
from utils.prompt_utils import normalize_json_response
from utils.validation import (
    ensure_valid_structure,
    validate_constraint_alignment,
    validate_objective_alignment,
    ValidationError,
)
from utils.math_validator import check_math_feasibility

_FREE_DOMAIN_POOL = [
    "urban transportation and traffic flow management",
    "pharmaceutical supply chain and cold-chain logistics",
    "renewable energy portfolio optimization (wind/solar/storage)",
    "financial portfolio allocation under risk constraints",
    "hospital staff scheduling and resource allocation",
    "disaster relief logistics and humanitarian aid distribution",
    "smart manufacturing and job-shop scheduling",
    "cloud computing resource provisioning and load balancing",
    "agricultural land-use and irrigation planning",
    "telecommunications network capacity expansion",
    "airline crew and fleet assignment",
    "water distribution network operations",
    "mining extraction scheduling with equipment constraints",
    "urban green infrastructure and waste management",
    "multi-echelon inventory management for retail chains",
    "power grid unit commitment and economic dispatch",
    "offshore oil and gas platform operations",
    "carbon emission trading and permit allocation",
    "e-commerce order fulfillment and last-mile delivery",
    "university course timetabling and room assignment",
]

_TYPE_INSTRUCTIONS = {
    "LP": """

PROBLEM TYPE REQUIREMENT: Generate an LP (Linear Program).
- All variables must be continuous (no integer_variables field, or set to []).
- The objective_function must be purely linear (no x^2, no x_i*x_j terms).
- All constraints must be linear equalities or inequalities.
""",
    "MILP": """

PROBLEM TYPE REQUIREMENT: Generate a MILP (Mixed-Integer Linear Program).
- At least one variable MUST be declared as integer or binary in the "integer_variables" field of structure.
- The bounds section MUST explicitly state which variables are integer or binary
  (e.g. "x1, x2 ∈ {0,1} binary; x3 integer >= 0").
- The objective_function must be purely linear (no quadratic terms).
- All constraints must be linear.
""",
    "QP": """

PROBLEM TYPE REQUIREMENT: Generate a QP (Quadratic Program).
- All variables must be continuous (no integer_variables).
- The objective_function MUST contain at least one quadratic term: either x^2 (e.g. "2*x1^2")
  or a product of two different variables (e.g. "x1*x2").
- Constraints must be linear.
""",
    "MINLP": """

PROBLEM TYPE REQUIREMENT: Generate a MINLP (Mixed-Integer Nonlinear Program).
- At least one variable MUST be declared as integer or binary in the "integer_variables" field of structure.
- The bounds section MUST explicitly state which variables are integer or binary.
- The objective_function MUST contain at least one quadratic term (x^2 or x_i*x_j).
- Constraints must be linear.
- This combines integer variables (like MILP) AND a quadratic objective (like QP).
""",
}


def _build_type_instruction(target_type: str | None) -> str:
    if not target_type:
        return ""
    return _TYPE_INSTRUCTIONS.get(target_type.upper(), "")


class ContentAgent:
    def __init__(
        self,
        llm_client: BaseLLMClient | None = None,
        system_prompt: str | None = None,
        seed_hints: Dict[str, Dict[str, str]] | None = None,
        max_math_attempts: int = 3,
        max_question_attempts: int = 3,
        problem_type_config: Dict | None = None,
        free_gen_ratio: float = 0.5,
    ):
        self.client = llm_client or MockLLMClient()
        self.system_prompt = system_prompt or (
            "You author mathematically precise optimization problems that follow the blueprint."
        )
        self.seed_hints = seed_hints or {}
        self.max_math_attempts = max(1, max_math_attempts)
        self.max_question_attempts = max(1, max_question_attempts)
        self.problem_type_config = problem_type_config or {}
        self.free_gen_ratio = max(0.0, min(1.0, free_gen_ratio))
        self._problem_type_queue = []
        self._init_problem_type_queue()

    def _init_problem_type_queue(self):
        if not self.problem_type_config.get("enabled"):
            return
        import random
        types = self.problem_type_config.get("types", ["LP", "MILP", "QP", "MINLP"])
        weights = self.problem_type_config.get("weights", [0.4, 0.3, 0.2, 0.1])
        self._problem_type_queue = random.choices(types, weights=weights, k=100)
        random.shuffle(self._problem_type_queue)

    def _get_target_problem_type(self) -> str | None:
        if not self.problem_type_config.get("enabled") or not self._problem_type_queue:
            return None
        return self._problem_type_queue.pop(0)

    def run(
        self,
        blueprints: List[StructureBlueprint],
        existing: List[GeneratedProblem] | None = None,
        on_problem: object = None,
    ) -> List[GeneratedProblem]:
        problems: List[GeneratedProblem] = list(existing or [])
        skip = len(problems)
        if skip:
            print(f"[content] resuming from problem {skip + 1}/{len(blueprints)} "
                  f"({skip} already cached)")
        for blueprint in blueprints[skip:]:
            try:
                problem = self._process_one_blueprint(blueprint)
                problems.append(problem)
                if on_problem is not None:
                    on_problem(problem)
            except Exception as exc:
                print(f"[content] skipping blueprint '{blueprint.name}': {exc}")
        return problems

    def _process_one_blueprint(self, blueprint: StructureBlueprint) -> GeneratedProblem:
        target_type = self._get_target_problem_type()
        type_instruction = _build_type_instruction(target_type)

        structure, constraint_defs, objective_fn = None, None, None
        math_feedback = ""
        math_status   = "SOLVE_FAIL"
        for math_attempt in range(1, self.max_math_attempts + 1):
            prompt = MATHEMATICAL_BRIEF_TEMPLATE.format(
                blueprint_summary=format_blueprint_summary(
                    blueprint.to_prompt_dict())
            ) + type_instruction + math_feedback

            raw = self.client.generate(prompt, system_prompt=self.system_prompt)
            math_payload = self._extract_math_payload(raw, blueprint)

            if isinstance(math_payload, GeneratedProblem):
                return math_payload

            s, cd, obj = math_payload
            probe = {
                "structure": {
                    "variables": s.variables,
                    "problem_type": s.problem_type,
                    "integer_variables": s.integer_variables or [],
                },
                "constraint_definitions": cd,
                "objective_function": obj,
                "meta": {"integer_variables": s.integer_variables or []},
            }
            math_result = check_math_feasibility(probe)
            math_status = math_result["status"]

            if math_status in ("INFEASIBLE", "UNBOUNDED", "ZERO_ONLY"):
                hint = math_result.get("hint", math_status)
                math_feedback = (
                    f"\n\nPREVIOUS ATTEMPT FAILED MATH VALIDATION ({math_status}): {hint}. "
                    f"Fix the constraint coefficients / bounds so the problem is feasible and bounded."
                )
                continue  


            structure, constraint_defs, objective_fn = s, cd, obj
            break

        if structure is None:
            return self._fallback_problem(
                blueprint,
                reason=f"math validation failed after {self.max_math_attempts} attempts: {math_status}")

        seed_context, override_domain = self._seed_context_for_blueprint(blueprint)

        original_domain_hint = blueprint.domain_hint
        if override_domain is not None:
            blueprint.domain_hint = override_domain
        question, question_meta = self._generate_question_with_feedback(
            blueprint,
            constraint_defs,
            objective_fn,
            seed_context,
        )
        blueprint.domain_hint = original_domain_hint 

        if override_domain is not None:
            if "[FREE GENERATION MODE]" in seed_context:
                question_meta["nl_mode"] = "free"
            else:
                question_meta["nl_mode"] = "contrast"
        else:
            question_meta["nl_mode"] = "imitate"

        meta = {
            "generated_via": "content-agent",
            "source_blueprint": blueprint.name,
            "sources": blueprint.source_signature_ids,
            "decomposition": blueprint.decomposition,
            "question_generation": question_meta,
        }
        if structure.integer_variables:
            meta["integer_variables"] = structure.integer_variables

        return GeneratedProblem(
            question=question,
            structure=structure,
            constraint_definitions=constraint_defs,
            objective_function=objective_fn,
            meta=meta,
        )

    def _extract_math_payload(
        self, response: str, blueprint: StructureBlueprint
    ) -> GeneratedProblem | tuple[ProblemStructure, dict, str]:
        cleaned = normalize_json_response(response)
        try:
            payload = json.loads(cleaned)
            blueprint_struct = blueprint.structure.to_dict()
            structure_payload = payload.get("structure") or {}

            def _field(key: str):
                value = structure_payload.get(key)
                return value if value not in (None, []) else blueprint_struct.get(key)

            structure = ProblemStructure(
                variables=_field("variables"),
                constraints=_field("constraints"),
                variable_constraint_graph=_field("variable_constraint_graph"),
                variable_connection_graph=_field("variable_connection_graph"),
                constraint_connection_graph=_field(
                    "constraint_connection_graph"),
                objective_variables=_field("objective_variables"),
                problem_type=_field("problem_type")
                or blueprint.structure.problem_type,
                domain=_field("domain") or blueprint.structure.domain,
                integer_variables=_field("integer_variables"),
            )
            structure.ensure_graphs()
            try:
                ensure_valid_structure(
                    structure, context=f"content:{blueprint.name}"
                )
            except ValidationError as exc:
                return self._fallback_problem(blueprint, reason=str(exc))

            constraint_defs = payload.get("constraint_definitions")
            if not isinstance(constraint_defs, dict):
                return self._fallback_problem(
                    blueprint,
                    reason="content response missing 'constraint_definitions' dict",
                )
            objective_fn = payload.get("objective_function")
            if not isinstance(objective_fn, str):
                return self._fallback_problem(
                    blueprint,
                    reason="content response missing textual objective",
                )

            issues = validate_constraint_alignment(structure, constraint_defs)
            issues += validate_objective_alignment(structure, objective_fn)
            if issues:
                return self._fallback_problem(
                    blueprint, reason="; ".join(issues)
                )
            return structure, constraint_defs, objective_fn
        except json.JSONDecodeError:
            return self._fallback_problem(
                blueprint, reason="content response is not valid JSON"
            )
        except Exception as exc:  
            return self._fallback_problem(
                blueprint, reason=f"content parsing failed: {exc}"
            )

    def _generate_question_with_feedback(
        self,
        blueprint: StructureBlueprint,
        constraint_defs: dict,
        objective_fn: str,
        seed_context: str,
    ) -> Tuple[str, Dict[str, object]]:
        feedback = "No prior feedback. Provide your best enriched scenario."
        attempt_records: List[Dict[str, object]] = []
        for attempt in range(1, self.max_question_attempts + 1):
            payload, raw_text, error = self._request_question_payload(
                blueprint, constraint_defs, objective_fn, seed_context, feedback
            )
            if error:
                attempt_records.append(
                    {"attempt": attempt, "issue": error, "raw": raw_text}
                )
                feedback = f"Previous attempt issue: {error}. Regenerate and fix it."
                continue
            valid, reason = self._question_payload_valid(blueprint, payload)
            if valid:
                scenario = str(payload.get("scenario", "")).strip()
                question_body = str(payload.get("question", "")).strip()
                combined = f"{scenario}\n\n{question_body}".strip()
                meta = {
                    "attempts": attempt,
                    "status": "ok",
                    "attempt_history": attempt_records,
                }
                return combined, meta
            attempt_records.append(
                {"attempt": attempt, "issue": reason, "raw": payload}
            )
            feedback = f"Previous attempt issue: {reason}. Regenerate and fix it."

        fallback_text = self._fallback_question(blueprint)
        meta = {
            "attempts": self.max_question_attempts,
            "status": "fallback",
            "attempt_history": attempt_records,
        }
        return fallback_text, meta

    def _request_question_payload(
        self,
        blueprint: StructureBlueprint,
        constraint_defs: dict,
        objective_fn: str,
        seed_context: str,
        feedback: str,
    ) -> Tuple[dict | None, str | None, str | None]:
        prompt = QUESTION_BRIEF_TEMPLATE.format(
            blueprint_summary=format_blueprint_summary(
                blueprint.to_prompt_dict()),
            constraint_summary=format_constraint_summary(constraint_defs),
            objective_summary=objective_fn,
            seed_context=seed_context,
            feedback_block=feedback,
        )
        try:
            raw = self.client.generate(
                prompt, system_prompt=self.system_prompt)
        except Exception as exc:  
            return None, None, f"LLM question call failed: {exc}"
        cleaned = normalize_json_response(raw)
        try:
            payload = json.loads(cleaned)
        except json.JSONDecodeError as exc:
            return None, cleaned, f"LLM question response invalid JSON: {exc}"
        return payload, cleaned, None

    def _question_payload_valid(
        self,
        blueprint: StructureBlueprint,
        payload: dict,
    ) -> Tuple[bool, str]:
        scenario = str(payload.get("scenario", "")).strip()
        question_body = str(payload.get("question", "")).strip()
        coverage = payload.get("coverage") or {}
        variables = coverage.get("variables")
        constraints = coverage.get("constraints")
        objective_text = str(coverage.get("objective", "")).strip()

        errors: List[str] = []
        if len(scenario.split()) < 8:
            errors.append("scenario must contain at least 8 words")
        if len(question_body.split()) < 25:
            errors.append("question body must contain at least 25 words")

        expected_vars = sorted({str(var)
                               for var in blueprint.structure.variables})
        provided_vars = sorted({str(var) for var in (variables or [])})
        if expected_vars != provided_vars:
            errors.append(
                "coverage.variables must list every blueprint variable exactly once")

        expected_cons = sorted({str(name)
                               for name in blueprint.structure.constraints})
        provided_cons = sorted({str(name) for name in (constraints or [])})
        if expected_cons != provided_cons:
            errors.append(
                "coverage.constraints must list every blueprint constraint exactly once")

        if not objective_text or not any(
            token in objective_text.lower() for token in ("minimize", "maximize")
        ):
            errors.append(
                "coverage.objective must mention minimize or maximize")

        combined = f"{scenario} {question_body}".lower()
        if expected_vars and not any(var.lower() in combined for var in expected_vars):
            errors.append(
                "question must mention at least one decision variable")

        domain_hint = (blueprint.domain_hint or "").lower()
        domain_tokens = [
            token for token in re.split(r"[^a-z0-9]+", domain_hint) if len(token) >= 4
        ]
        if domain_tokens and not any(token in combined for token in domain_tokens):
            errors.append("question must reference the domain hint/context")

        if errors:
            return False, "; ".join(errors)
        return True, ""

    def _seed_context_for_blueprint(
        self, blueprint: StructureBlueprint
    ) -> Tuple[str, str | None]:
        problem_types = set()
        has_integer = False
        contexts: List[str] = []

        for sig_id in blueprint.source_signature_ids:
            hint = self.seed_hints.get(sig_id)
            if not hint:
                continue
            question = (hint.get("question") or "").strip()
            summary = (hint.get("summary") or "").strip()
            if question:
                contexts.append(f"- {sig_id}: {question}")
            elif summary:
                contexts.append(f"- {sig_id}: {summary}")
            ptype = hint.get("problem_type")
            if ptype:
                problem_types.add(ptype)
            if hint.get("integer_variables"):
                has_integer = True

        type_hint = ""
        if problem_types:
            types_str = ", ".join(sorted(problem_types))
            type_hint = f"\nSeed problem types: {types_str}"
            if has_integer:
                type_hint += " (some seeds contain integer variables)"

        r = random.random()

        if r < self.free_gen_ratio / 2:
            chosen_domain = random.choice(_FREE_DOMAIN_POOL)
            ctx = (
                f"[FREE GENERATION MODE] Do NOT imitate any existing seed narrative. "
                f"Invent an entirely new real-world scenario from scratch in the domain of: "
                f"**{chosen_domain}**. "
                f"The mathematical structure is fixed; only the story and context should be original."
                + type_hint
            )
            return ctx, chosen_domain

        if r < self.free_gen_ratio:
            seed_text = "\n".join(contexts) if contexts else "(no prior narratives)"
            chosen_domain = random.choice(_FREE_DOMAIN_POOL)
            ctx = (
                f"[CONTRAST GENERATION MODE] The following are the ORIGINAL seed narratives "
                f"you must NOT imitate — treat them as forbidden territory:\n"
                f"{seed_text}\n\n"
                f"Create a scenario that is thematically and lexically distinct from the above. "
                f"Use the domain: **{chosen_domain}** as inspiration for your new scenario."
                + type_hint
            )
            return ctx, chosen_domain

        if contexts:
            return "\n".join(contexts) + type_hint, None
        return f"  (no prior narratives available){type_hint}", None

    def _fallback_problem(self, blueprint: StructureBlueprint, reason: str | None = None) -> GeneratedProblem:
        structure = blueprint.structure
        structure.ensure_graphs()
        meta = {
            "generated_via": "fallback",
            "source_blueprint": blueprint.name,
            "sources": blueprint.source_signature_ids,
            "decomposition": blueprint.decomposition,
        }
        if reason:
            meta["validation_issue"] = reason
        return GeneratedProblem(
            question=self._fallback_question(blueprint),
            structure=structure,
            constraint_definitions=self._fallback_constraints(structure),
            objective_function=self._fallback_objective(structure),
            meta=meta,
        )

    def _fallback_question(self, blueprint: StructureBlueprint) -> str:
        return (
            f"Design a decomposable planning problem in the domain of {blueprint.domain_hint} "
            f"with {len(blueprint.structure.variables)} decision variables arranged across "
            f"{len(blueprint.structure.constraints)} constraints and the described coupling pattern."
        )

    def _fallback_constraints(self, structure: ProblemStructure):
        constraints = {}
        for idx, (constraint, vars_in_c) in enumerate(structure.variable_constraint_graph.items(), start=1):
            coeffs = [round(1.0 + 0.3 * idx + 0.1 * i, 2)
                      for i in range(len(vars_in_c))]
            terms = [f"{coeff}*{var}" for coeff, var in zip(coeffs, vars_in_c)]
            if idx % 3 == 0:
                expr = " + ".join(terms) + f" = {10 + idx}"
            else:
                expr = " + ".join(terms) + f" <= {20 + 2 * idx}"
            constraints[constraint] = expr
        constraints["bounds"] = ", ".join(structure.variables) + " >= 0"
        return constraints

    def _fallback_objective(self, structure: ProblemStructure) -> str:
        coeffs = [round(1 + 0.5 * i, 2)
                  for i in range(len(structure.variables))]
        terms = [f"{c}*{v}" for c, v in zip(coeffs, structure.variables)]
        return "minimize " + " + ".join(terms)
