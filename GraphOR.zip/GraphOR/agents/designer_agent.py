from __future__ import annotations

import itertools
import json
import random
from textwrap import dedent
from typing import List, Sequence, Optional, Dict, Callable, Tuple, Any

from utils.data_models import StructureBlueprint, StructureSignature, ProblemStructure
from utils.graph_utils import scale_structure, combine_structures, generate_sbm_structure
from utils.llm_client import BaseLLMClient
from utils.prompt_utils import normalize_json_response
from utils.validation import ensure_valid_structure, ValidationError
from utils.wl_similarity import wl_similarity_to_signatures


class StrategyError(RuntimeError):
    pass


def _similarity_hint(target: str | None) -> str:
    if target == "high":
        return (
            " Maintain a topology closely similar to the seed: "
            "preserve the same coupling pattern, sparsity level, and block structure."
        )
    if target == "low":
        return (
            " Create a topology structurally different from the seed: "
            "use a different coupling pattern (e.g. denser or sparser), "
            "different number of blocks, or a different graph motif (star vs chain vs hierarchical)."
        )
    return "" 


LLM_STRUCTURE_PROMPT = dedent(
    """
    You are an expert in decomposable optimization structures.
    Goal: {goal}

    Seed blueprint (JSON):
    {seed_json}

    Respond with EXACTLY one JSON object that conforms to:
    {{"name": string, "domain_hint": string, "note": string,
      "structure": {{"variables": [string], "constraints": [string],
                     "variable_constraint_graph": {{string: [string]}},
                     "problem_type": string, "domain": string}}}}

    Requirements:
    - Use only declared variables inside each constraint incidence list.
    - Every constraint must reference at least two variables; reuse names when expanding existing blocks.
    - When scaling up, include strictly more variables OR constraints than the input blueprint and add at least one coupling-style constraint.
    - Keep the JSON parseable by json.loads with no markdown fences or commentary.

    Example output:
    {{"name": "scaled_supply_chain", "domain_hint": "multi-region logistics", "note": "Scaled two sub-blocks and added shared capacity", "structure": {{"variables": ["x_a1", "x_a2", "y_b1"], "constraints": ["c_supply", "c_balance", "c_coupling"], "variable_constraint_graph": {{"c_supply": ["x_a1", "x_a2"], "c_balance": ["x_a2", "y_b1"], "c_coupling": ["x_a1", "y_b1"]}}, "problem_type": "planning", "domain": "logistics"}}}}
    """
)


class DesignerAgent:
    def __init__(
        self,
        mode: str,
        scale_factor: int = 1,
        blueprint_count: int = 4,  
        seed: int = 1234,
        llm_client: Optional[BaseLLMClient] = None,
        system_prompt: str | None = None,
        manual_scale_factor: int | None = None,
        strategy_config: Optional[Dict[str, Any]] = None,
    ):
        self.mode = (mode or "auto").lower()
        self.scale_factor_limit = max(2, scale_factor)
        self.manual_scale_factor = (
            manual_scale_factor if manual_scale_factor and manual_scale_factor > 1 else None
        )
        self.blueprint_count = blueprint_count
        self.rng = random.Random(seed)
        self.llm_client = llm_client
        self.system_prompt = system_prompt or (
            "You propose realistic domains and decomposition notes for structural blueprints."
        )

        strategy_cfg = strategy_config or {}
        self.randomize_mode = self.mode in ("auto", "random")
        self.llm_bucket_weight = float(strategy_cfg.get("llm_weight", 0.4))
        self.non_llm_strategy_names = strategy_cfg.get(
            "non_llm_strategies",
            ["scale", "combine", "random_graph", "generate", "replicate"],
        )
        self.llm_strategy_names = strategy_cfg.get(
            "llm_strategies",
            ["llm_scale_up", "llm_focus_blocks", "llm_random_variation"],
        )

        raw_weights = strategy_cfg.get("non_llm_weights", [])
        if raw_weights and len(raw_weights) == len(self.non_llm_strategy_names):
            self.non_llm_weights = [max(0.0, float(w)) for w in raw_weights]
        else:
            self.non_llm_weights = [1.0] * len(self.non_llm_strategy_names)
        self.scale_factor_bounds = self._parse_scale_bounds(
            strategy_cfg.get("scale_factor_range"))
        self.random_graph_cfg = self._parse_random_graph_cfg(
            strategy_cfg.get("random_graph"))

        self.variable_range   = self._normalize_range(
            strategy_cfg.get("variable_range", [20, 80]), (20, 80))
        self.constraint_range = self._normalize_range(
            strategy_cfg.get("constraint_range", [15, 60]), (15, 60))
        self.block_range      = self._normalize_range(
            strategy_cfg.get("block_range", [2, 6]), (2, 6))
        self.coupling_ratio   = self._normalize_float_range(
            strategy_cfg.get("coupling_ratio", [0.05, 0.15]), (0.05, 0.15))
        self.strategy_max_attempts = max(
            5, int(strategy_cfg.get("max_attempts", blueprint_count * 4)))

        diversity_cfg = strategy_config.get("diversity", {}) if strategy_config else {}
        self.diversity_enabled        = bool(diversity_cfg.get("enabled", False))
        self.wl_high_threshold        = float(diversity_cfg.get("high_similarity_threshold", 0.7))
        self.wl_low_threshold         = float(diversity_cfg.get("low_similarity_threshold", 0.4))
        self.diversity_high_ratio     = float(diversity_cfg.get("high_ratio", 0.4))
        self.diversity_low_ratio      = float(diversity_cfg.get("low_ratio", 0.4))
        self.wl_max_retries           = int(diversity_cfg.get("wl_max_retries", 3))
        self.wl_iterations            = int(diversity_cfg.get("wl_iterations", 3))
        affinity_cfg = strategy_cfg.get("similarity_affinity", {})
        self._strategy_affinity: Dict[str, str] = {
            "scale":               affinity_cfg.get("scale", "high"),
            "replicate":           affinity_cfg.get("replicate", "high"),
            "combine":             affinity_cfg.get("combine", "medium"),
            "llm_scale_up":        affinity_cfg.get("llm_scale_up", "high"),
            "llm_focus_blocks":    affinity_cfg.get("llm_focus_blocks", "medium"),
            "generate":            affinity_cfg.get("generate", "low"),
            "random_graph":        affinity_cfg.get("random_graph", "low"),
            "llm_random_variation":affinity_cfg.get("llm_random_variation", "low"),
        }

    def run(
        self,
        signatures: Sequence[StructureSignature],
        existing: Optional[List[StructureBlueprint]] = None,
        on_blueprint: Optional[Callable[[StructureBlueprint], None]] = None,
    ) -> List[StructureBlueprint]:
        if not signatures:
            return []
        preloaded = list(existing) if existing else []
        if len(preloaded) >= self.blueprint_count:
            print(f"[designer] Resuming: {len(preloaded)} blueprints already available "
                  f"(need {self.blueprint_count}) — skipping generation.")
            return preloaded[: self.blueprint_count]
        if preloaded:
            print(f"[designer] Resuming: {len(preloaded)} blueprints cached, "
                  f"need {self.blueprint_count - len(preloaded)} more.")
        if self.randomize_mode:
            return self._run_randomized(signatures, preloaded, on_blueprint)
        return self._run_specific_mode(signatures, preloaded, on_blueprint)

    def _run_specific_mode(
        self,
        signatures: Sequence[StructureSignature],
        preloaded: List[StructureBlueprint],
        on_blueprint: Optional[Callable[[StructureBlueprint], None]],
    ) -> List[StructureBlueprint]:
        mode = self.mode
        legacy_handlers = {
            "replicate": self._replicate,
            "scale": self._scale,
            "combine": self._combine,
            "generate": self._generate,
        }
        if mode in legacy_handlers:
            blueprints = legacy_handlers[mode](signatures)
        else:
            blueprints = self._generate_with_strategy(mode, signatures, self.blueprint_count)

        if on_blueprint:
            for bp in blueprints:
                on_blueprint(bp)
        return preloaded + blueprints

    def _run_randomized(
        self,
        signatures: Sequence[StructureSignature],
        preloaded: List[StructureBlueprint],
        on_blueprint: Optional[Callable[[StructureBlueprint], None]],
    ) -> List[StructureBlueprint]:
        if self.diversity_enabled:
            return self._run_randomized_diverse(signatures, preloaded, on_blueprint)
        return self._run_randomized_basic(signatures, preloaded, on_blueprint)

    def _run_randomized_basic(
        self,
        signatures: Sequence[StructureSignature],
        preloaded: List[StructureBlueprint],
        on_blueprint: Optional[Callable[[StructureBlueprint], None]],
    ) -> List[StructureBlueprint]:
        blueprints: List[StructureBlueprint] = list(preloaded)
        attempts = 0
        max_attempts = max(self.strategy_max_attempts, self.blueprint_count * 3)
        while len(blueprints) < self.blueprint_count and attempts < max_attempts:
            strategy_name = self._pick_random_strategy()
            try:
                blueprint = self._build_single_blueprint(strategy_name, signatures)
            except (StrategyError, ValidationError, Exception) as exc:
                attempts += 1
                print(f"[designer] skipping blueprint (strategy={strategy_name}): {exc}")
                continue
            if on_blueprint:
                on_blueprint(blueprint)
            blueprints.append(blueprint)
            print(f"[designer] blueprint {len(blueprints)}/{self.blueprint_count} accepted "
                  f"(strategy={strategy_name})")
        if not blueprints:
            raise StrategyError("Randomized designer failed to create any blueprints")
        return blueprints

    def _run_randomized_diverse(
        self,
        signatures: Sequence[StructureSignature],
        preloaded: List[StructureBlueprint],
        on_blueprint: Optional[Callable[[StructureBlueprint], None]],
    ) -> List[StructureBlueprint]:
        n       = self.blueprint_count
        n_high  = round(n * self.diversity_high_ratio)
        n_low   = round(n * self.diversity_low_ratio)
        n_any   = max(0, n - n_high - n_low)

        targets = (["high"] * n_high + ["medium"] * n_any + ["low"] * n_low)
        self.rng.shuffle(targets)  

        blueprints: List[StructureBlueprint] = list(preloaded)
        target_idx = len(preloaded)
        max_attempts = max(self.strategy_max_attempts, n * 5)
        global_attempts = 0
        slot_retry_counts: Dict[int, int] = {}  
        while len(blueprints) < n and global_attempts < max_attempts:
            current_target = targets[target_idx] if target_idx < len(targets) else "any"
            strategy_name  = self._pick_strategy_for_target(current_target)

            try:
                blueprint = self._build_single_blueprint(
                    strategy_name, signatures,
                    similarity_target=current_target if self._is_llm_strategy(strategy_name) else None,
                )
            except (StrategyError, ValidationError, Exception) as exc:
                global_attempts += 1
                print(f"[designer] skipping blueprint (strategy={strategy_name}): {exc}")
                continue

            wl_score = wl_similarity_to_signatures(
                blueprint.structure, signatures, self.wl_iterations)
            blueprint.decomposition["wl_score"] = wl_score
            blueprint.decomposition["similarity_target"] = current_target

            if self._wl_satisfies(wl_score, current_target):
                if on_blueprint:
                    on_blueprint(blueprint)
                blueprints.append(blueprint)
                slot_retry_counts.pop(target_idx, None)  
                target_idx += 1
                global_attempts = 0       
                print(f"[designer] blueprint {len(blueprints)}/{n} accepted "
                      f"(strategy={strategy_name}, wl={wl_score:.3f}, target={current_target})")
            else:
                slot_retries = slot_retry_counts.get(target_idx, 0) + 1
                slot_retry_counts[target_idx] = slot_retries
                if slot_retries >= self.wl_max_retries:
                    blueprint.decomposition["wl_accepted_despite_miss"] = True
                    blueprint.decomposition["_wl_retries"] = slot_retries
                    print(f"[designer] WL target '{current_target}' not met "
                          f"(score={wl_score:.3f}) after {slot_retries} retries — accepting")
                    if on_blueprint:
                        on_blueprint(blueprint)
                    blueprints.append(blueprint)
                    slot_retry_counts.pop(target_idx, None) 
                    target_idx += 1
                    global_attempts = 0
                else:
                    blueprint.decomposition["_wl_retries"] = slot_retries
                    global_attempts += 1

        if not blueprints:
            raise StrategyError("Randomized designer failed to create any blueprints")
        return blueprints

    def _pick_random_strategy(self) -> str:
        non_llm = [name for name in self.non_llm_strategy_names if name]
        llm = [name for name in self.llm_strategy_names if name]
        has_llm = bool(self.llm_client) and bool(llm)
        has_non_llm = bool(non_llm)
        if not has_llm and not has_non_llm:
            raise StrategyError("No strategies configured for designer agent")

        bucket_roll = self.rng.random()
        if has_llm and has_non_llm:
            llm_weight = min(0.95, max(0.0, self.llm_bucket_weight))
            if bucket_roll < llm_weight:
                return self.rng.choice(llm)
            weights = [self.non_llm_weights[i]
                       for i, n in enumerate(self.non_llm_strategy_names)
                       if n in non_llm]
            return self.rng.choices(non_llm, weights=weights, k=1)[0]
        if has_llm:
            return self.rng.choice(llm)
        weights = [self.non_llm_weights[i]
                   for i, n in enumerate(self.non_llm_strategy_names)
                   if n in non_llm]
        return self.rng.choices(non_llm, weights=weights, k=1)[0]

    def _pick_strategy_for_target(self, target: str) -> str:
        all_strategies = self.non_llm_strategy_names + (
            self.llm_strategy_names if self.llm_client else [])
        preferred = [s for s in all_strategies
                     if self._strategy_affinity.get(s, "any") == target]
        if preferred:
            non_llm_pref = [s for s in preferred if s in self.non_llm_strategy_names]
            llm_pref     = [s for s in preferred if s in self.llm_strategy_names]
            if non_llm_pref and llm_pref:
                if self.rng.random() < self.llm_bucket_weight:
                    return self.rng.choice(llm_pref)
                weights = [self.non_llm_weights[self.non_llm_strategy_names.index(s)]
                           for s in non_llm_pref if s in self.non_llm_strategy_names]
                return self.rng.choices(non_llm_pref, weights=weights, k=1)[0]
            if llm_pref:
                return self.rng.choice(llm_pref)
            weights = [self.non_llm_weights[self.non_llm_strategy_names.index(s)]
                       for s in non_llm_pref if s in self.non_llm_strategy_names]
            return self.rng.choices(non_llm_pref, weights=weights, k=1)[0]
        return self._pick_random_strategy()

    def _is_llm_strategy(self, name: str) -> bool:
        return name in self.llm_strategy_names

    def _wl_satisfies(self, score, target):
        if target == "high":
            return score >= self.wl_high_threshold
        if target == "medium":
            return self.wl_low_threshold <= score <= self.wl_high_threshold
        if target == "low":
            return score <= self.wl_low_threshold
        return True

    def _generate_with_strategy(
        self,
        strategy_name: str,
        signatures: Sequence[StructureSignature],
        target_count: int,
    ) -> List[StructureBlueprint]:
        blueprints: List[StructureBlueprint] = []
        attempts = 0
        per_strategy_limit = max(target_count * 3, 6)
        while len(blueprints) < target_count and attempts < per_strategy_limit:
            try:
                blueprint = self._build_single_blueprint(
                    strategy_name, signatures)
            except (StrategyError, ValidationError, Exception) as exc:
                attempts += 1
                print(f"[designer] skipping blueprint (strategy={strategy_name}): {exc}")
                continue
            blueprints.append(blueprint)
        if not blueprints:
            raise StrategyError(
                f"Strategy '{strategy_name}' failed to produce blueprints")
        return blueprints

    def _build_single_blueprint(
        self,
        strategy_name: str,
        signatures: Sequence[StructureSignature],
        similarity_target: str | None = None,
    ) -> StructureBlueprint:
        handler = self._single_strategy_handlers().get(strategy_name)
        if not handler:
            raise StrategyError(
                f"Unsupported design strategy: {strategy_name}")
        if similarity_target and self._is_llm_strategy(strategy_name):
            blueprint = handler(signatures, similarity_target=similarity_target)
        else:
            blueprint = handler(signatures)
        if not blueprint:
            raise StrategyError(
                f"Strategy {strategy_name} did not return a blueprint")
        return blueprint

    def _single_strategy_handlers(self) -> Dict[str, Callable[[Sequence[StructureSignature]], StructureBlueprint]]:
        return {
            "replicate": self._strategy_replicate_single,
            "scale": self._strategy_scale_single,
            "combine": self._strategy_combine_single,
            "generate": self._strategy_generate_single,
            "random_graph": self._strategy_random_graph_single,
            "llm_scale_up": self._strategy_llm_scale_up_single,
            "llm_focus_blocks": self._strategy_llm_focus_blocks_single,
            "llm_random_variation": self._strategy_llm_random_variation_single,
        }

    def _sample_scale_factor(self) -> int:
        if self.manual_scale_factor:
            return self.manual_scale_factor
        low, high = self.scale_factor_bounds
        if low == high:
            return low
        return self.rng.randint(low, high)

    def _unique_suffix(self) -> str:
        return f"{self.rng.randint(1000, 9999)}"

    def _finalize_blueprint(
        self,
        blueprint: StructureBlueprint,
        annotate: bool = True,
    ) -> StructureBlueprint:
        self._validate_blueprint(blueprint)
        if annotate:
            self._annotate_with_llm(blueprint)
        return blueprint

    def _random_signature(self, signatures: Sequence[StructureSignature]) -> StructureSignature:
        if not signatures:
            raise StrategyError("No signatures available for strategy")
        return signatures[self.rng.randrange(len(signatures))]

    def _random_signature_pair(
        self, signatures: Sequence[StructureSignature]
    ) -> Tuple[StructureSignature, StructureSignature]:
        if len(signatures) >= 2:
            idx_a, idx_b = self.rng.sample(range(len(signatures)), 2)
            return signatures[idx_a], signatures[idx_b]
        signature = self._random_signature(signatures)
        return signature, signature

    def _signature_stats(self, signatures: Sequence[StructureSignature]) -> Dict[str, int]:
        if not signatures:
            raise StrategyError("No signatures to derive statistics from")
        avg_vars = max(3, int(sum(len(sig.structure.variables)
                       for sig in signatures) / len(signatures)))
        avg_constraints = max(3, int(sum(len(sig.structure.constraints)
                              for sig in signatures) / len(signatures)))
        return {"avg_vars": avg_vars, "avg_constraints": avg_constraints}

    def _build_replicate_blueprint(
        self,
        signature: StructureSignature,
        *,
        suffix: str | None = None,
    ) -> StructureBlueprint:
        suffix_text = f"_{suffix}" if suffix else ""
        blueprint = StructureBlueprint(
            name=f"replicate_{signature.signature_id}{suffix_text}",
            structure=signature.structure,
            domain_hint=signature.metadata.get("domain", "operations"),
            decomposition={
                "mode": "replicate",
                "strategy": "replicate",
                "num_blocks": signature.num_blocks,
                "coupling_constraints": signature.coupling_constraints,
            },
            source_signature_ids=[signature.signature_id],
        )
        return self._finalize_blueprint(blueprint)

    def _parse_scale_bounds(self, cfg: Any) -> Tuple[int, int]:
        default_min = 2
        default_max = max(default_min, self.scale_factor_limit)
        if isinstance(cfg, dict):
            min_factor = int(cfg.get("min", default_min))
            max_factor = int(cfg.get("max", default_max))
        elif isinstance(cfg, (list, tuple)) and len(cfg) == 2:
            min_factor = int(cfg[0])
            max_factor = int(cfg[1])
        else:
            min_factor = default_min
            max_factor = default_max
        min_factor = max(2, min_factor)
        max_factor = max(min_factor, max_factor)
        return min_factor, max_factor

    def _parse_random_graph_cfg(self, cfg: Any) -> Dict[str, Any]:
        defaults = {
            "variable_range": (4, 8),
            "constraint_range": (3, 7),
            "min_incidence": 2,
            "max_incidence": 4,
        }
        if not isinstance(cfg, dict):
            return defaults
        variable_range = cfg.get("variable_range", defaults["variable_range"])
        constraint_range = cfg.get(
            "constraint_range", defaults["constraint_range"])
        min_inc = int(cfg.get("min_incidence", defaults["min_incidence"]))
        max_inc = int(cfg.get("max_incidence", defaults["max_incidence"]))
        return {
            "variable_range": self._normalize_range(variable_range, defaults["variable_range"]),
            "constraint_range": self._normalize_range(constraint_range, defaults["constraint_range"]),
            "min_incidence": max(1, min_inc),
            "max_incidence": max(max(1, min_inc), max_inc),
        }

    def _normalize_range(self, value: Any, fallback: Tuple[int, int]) -> Tuple[int, int]:
        if isinstance(value, (list, tuple)) and len(value) == 2:
            lo, hi = int(value[0]), int(value[1])
            if lo > hi:
                lo, hi = hi, lo
            return max(1, lo), max(max(1, lo), hi)
        return fallback

    def _normalize_float_range(self, value: Any, fallback: Tuple[float, float]) -> Tuple[float, float]:
        if isinstance(value, (list, tuple)) and len(value) == 2:
            lo, hi = float(value[0]), float(value[1])
            if lo > hi:
                lo, hi = hi, lo
            return max(0.0, lo), max(max(0.0, lo), hi)
        return fallback

    def _sample_from_range(self, range_tuple: Tuple[int, int]) -> int:
        lo, hi = range_tuple
        return self.rng.randint(lo, hi)

    def _sample_float_range(self, range_tuple: Tuple[float, float]) -> float:
        lo, hi = range_tuple
        return lo + self.rng.random() * (hi - lo)

    def _replicate(self, signatures: Sequence[StructureSignature]) -> List[StructureBlueprint]:
        blueprints: List[StructureBlueprint] = []
        for signature in signatures[: self.blueprint_count]:
            blueprints.append(self._build_replicate_blueprint(signature))
        if not blueprints:
            raise StrategyError(
                "Replicate mode requires at least one signature")
        return blueprints

    def _scale(self, signatures: Sequence[StructureSignature]) -> List[StructureBlueprint]:
        blueprints: List[StructureBlueprint] = []
        for signature in itertools.cycle(signatures):
            factor = self._sample_scale_factor()
            coupling_ratio = self._sample_float_range(self.coupling_ratio)
            scaled_structure = scale_structure(
                signature.structure, factor,
                coupling_ratio=coupling_ratio,
                rng=self.rng,
            )
            blueprint = StructureBlueprint(
                name=f"scale_x{factor}_{signature.signature_id}",
                structure=scaled_structure,
                domain_hint=signature.metadata.get("domain", "operations"),
                decomposition={
                    "mode": "scale",
                    "strategy": "scale",
                    "scale_factor": factor,
                    "base_signature": signature.signature_id,
                },
                source_signature_ids=[signature.signature_id],
            )
            blueprints.append(self._finalize_blueprint(blueprint))
            if len(blueprints) >= self.blueprint_count:
                break
        return blueprints

    def _combine(self, signatures: Sequence[StructureSignature]) -> List[StructureBlueprint]:
        blueprints: List[StructureBlueprint] = []
        pairs = zip(signatures[::2], signatures[1::2])
        for sig_a, sig_b in pairs:
            n_coupling = self.rng.randint(1, 3)
            combined_structure = combine_structures(
                sig_a.structure, sig_b.structure,
                n_coupling=n_coupling,
                rng=self.rng,
            )
            blueprint = StructureBlueprint(
                name=f"combine_{sig_a.signature_id}_{sig_b.signature_id}",
                structure=combined_structure,
                domain_hint=f"{sig_a.metadata.get('domain', 'ops')}_x_{sig_b.metadata.get('domain', 'ops')}",
                decomposition={
                    "mode": "combine",
                    "strategy": "combine",
                    "sources": [sig_a.signature_id, sig_b.signature_id],
                },
                source_signature_ids=[sig_a.signature_id, sig_b.signature_id],
            )
            blueprints.append(self._finalize_blueprint(blueprint))
            if len(blueprints) >= self.blueprint_count:
                break
        return blueprints

    def _generate(self, signatures: Sequence[StructureSignature]) -> List[StructureBlueprint]:
        blueprint_list: List[StructureBlueprint] = []
        for idx in range(self.blueprint_count):
            num_vars        = self._sample_from_range(self.variable_range)
            num_constraints = self._sample_from_range(self.constraint_range)
            variables   = [f"z{idx}_{i}" for i in range(1, num_vars + 1)]
            constraints = [f"c{idx}_{j}" for j in range(1, num_constraints + 1)]
            vc_graph = {}
            for constraint in constraints:
                span = self.rng.randint(2, min(4, num_vars))
                vc_graph[constraint] = self.rng.sample(variables, span)
            structure = ProblemStructure(
                variables=variables,
                constraints=constraints,
                variable_constraint_graph=vc_graph,
                problem_type="synthetic",
                domain="generated",
            )
            structure.ensure_graphs()
            blueprint = StructureBlueprint(
                name=f"generate_{idx}",
                structure=structure,
                domain_hint="automated synthesis",
                decomposition={
                    "mode": "generate",
                    "strategy": "generate",
                    "notes": "sampled from configured variable/constraint ranges",
                },
                source_signature_ids=[
                    sig.signature_id for sig in signatures],
            )
            blueprint_list.append(self._finalize_blueprint(blueprint))
        return blueprint_list



    def _strategy_replicate_single(self, signatures: Sequence[StructureSignature]) -> StructureBlueprint:
        signature = self._random_signature(signatures)
        return self._build_replicate_blueprint(signature, suffix=self._unique_suffix())

    def _strategy_scale_single(self, signatures: Sequence[StructureSignature]) -> StructureBlueprint:
        signature = self._random_signature(signatures)
        factor = self._sample_scale_factor()
        coupling_ratio = self._sample_float_range(self.coupling_ratio)
        scaled_structure = scale_structure(
            signature.structure, factor,
            coupling_ratio=coupling_ratio,
            rng=self.rng,
        )
        blueprint = StructureBlueprint(
            name=f"scale_x{factor}_{signature.signature_id}_{self._unique_suffix()}",
            structure=scaled_structure,
            domain_hint=signature.metadata.get("domain", "operations"),
            decomposition={
                "mode": "scale",
                "strategy": "scale",
                "scale_factor": factor,
                "base_signature": signature.signature_id,
            },
            source_signature_ids=[signature.signature_id],
        )
        return self._finalize_blueprint(blueprint)

    def _strategy_combine_single(self, signatures: Sequence[StructureSignature]) -> StructureBlueprint:
        sig_a, sig_b = self._random_signature_pair(signatures)
        n_coupling = self.rng.randint(1, 3)
        combined_structure = combine_structures(
            sig_a.structure, sig_b.structure,
            n_coupling=n_coupling,
            rng=self.rng,
        )
        blueprint = StructureBlueprint(
            name=f"combine_{sig_a.signature_id}_{sig_b.signature_id}_{self._unique_suffix()}",
            structure=combined_structure,
            domain_hint=f"{sig_a.metadata.get('domain', 'ops')}_x_{sig_b.metadata.get('domain', 'ops')}",
            decomposition={
                "mode": "combine",
                "strategy": "combine",
                "sources": [sig_a.signature_id, sig_b.signature_id],
            },
            source_signature_ids=[sig_a.signature_id, sig_b.signature_id],
        )
        return self._finalize_blueprint(blueprint)

    def _strategy_generate_single(self, signatures: Sequence[StructureSignature]) -> StructureBlueprint:
        num_vars        = self._sample_from_range(self.variable_range)
        num_constraints = self._sample_from_range(self.constraint_range)
        suffix = self._unique_suffix()
        variables = [f"zg{suffix}_{i}" for i in range(1, num_vars + 1)]
        constraints = [f"cg{suffix}_{j}" for j in range(
            1, num_constraints + 1)]
        vc_graph: Dict[str, List[str]] = {}
        min_inc = min(2, max(1, len(variables)))
        max_inc = min(4, len(variables))
        for constraint in constraints:
            span = self.rng.randint(min_inc, max_inc)
            vc_graph[constraint] = sorted(self.rng.sample(variables, span))
        used_vars = {v for vs in vc_graph.values() for v in vs}
        unused = [v for v in variables if v not in used_vars]
        for var in unused:
            chosen_c = self.rng.choice(constraints)
            vc_graph[chosen_c] = sorted(vc_graph[chosen_c] + [var])

        structure = ProblemStructure(
            variables=variables,
            constraints=constraints,
            variable_constraint_graph=vc_graph,
            problem_type="synthetic",
            domain="generated",
        )
        structure.ensure_graphs()
        blueprint = StructureBlueprint(
            name=f"generate_{suffix}",
            structure=structure,
            domain_hint="automated synthesis",
            decomposition={
                "mode": "generate",
                "strategy": "generate",
                "notes": "single-sample synthetic graph",
            },
            source_signature_ids=[sig.signature_id for sig in signatures],
        )
        return self._finalize_blueprint(blueprint)

    def _strategy_random_graph_single(self, signatures: Sequence[StructureSignature]) -> StructureBlueprint:
        var_lo,  var_hi  = self.random_graph_cfg["variable_range"]
        con_lo,  con_hi  = self.random_graph_cfg["constraint_range"]
        num_vars        = self.rng.randint(var_lo, var_hi)
        num_constraints = self.rng.randint(con_lo, con_hi)
        num_blocks      = self._sample_from_range(self.block_range)
        coupling_ratio  = self._sample_float_range(self.coupling_ratio)
        prefix          = f"rg{self._unique_suffix()}"

        structure = generate_sbm_structure(
            num_vars=num_vars,
            num_constraints=num_constraints,
            num_blocks=num_blocks,
            coupling_ratio=coupling_ratio,
            min_incidence=self.random_graph_cfg["min_incidence"],
            max_incidence=self.random_graph_cfg["max_incidence"],
            prefix=prefix,
            rng=self.rng,
        )
        blueprint = StructureBlueprint(
            name=f"random_graph_{prefix}",
            structure=structure,
            domain_hint="randomized decomposition",
            decomposition={
                "mode": "random_graph",
                "strategy": "random_graph",
                "notes": "Stochastic Block Model: intra-block dense, inter-block sparse",
                "num_blocks": num_blocks,
            },
            source_signature_ids=[],
        )
        return self._finalize_blueprint(blueprint)

    def _strategy_llm_scale_up_single(self, signatures: Sequence[StructureSignature],
                                       similarity_target: str | None = None) -> StructureBlueprint:
        signature      = self._random_signature(signatures)
        target_vars    = self._sample_from_range(self.variable_range)
        target_cons    = self._sample_from_range(self.constraint_range)
        target_blocks  = self._sample_from_range(self.block_range)
        target_coupling = max(target_blocks - 1,
                              int(target_cons * self._sample_float_range(self.coupling_ratio)))
        similarity_hint = _similarity_hint(similarity_target)
        goal = (
            f"Scale the blueprint to approximately {target_vars} variables, "
            f"{target_cons} constraints, and {target_blocks} blocks. "
            f"Add at least {target_coupling} inter-block coupling constraints. "
            "Ensure block-sparse structure: constraints within each block should be denser "
            "than constraints between blocks. Preserve the core decomposition intent of the seed."
            f"{similarity_hint}"
        )
        return self._llm_structure_from_seed(signature, goal, "llm_scale_up")

    def _strategy_llm_focus_blocks_single(self, signatures: Sequence[StructureSignature],
                                           similarity_target: str | None = None) -> StructureBlueprint:
        signature   = self._random_signature(signatures)
        focus_vars  = signature.structure.variables
        target_vars = self._sample_from_range(self.variable_range)
        target_cons = self._sample_from_range(self.constraint_range)
        if focus_vars:
            count  = min(max(2, len(focus_vars) // 2), len(focus_vars))
            subset = self.rng.sample(focus_vars, count)
            focus_text = ", ".join(subset)
        else:
            focus_text = "the primary decision block"
        similarity_hint = _similarity_hint(similarity_target)
        goal = (
            f"Select the highlighted variables and split each into multiple sub-variables "
            f"to capture finer-grain decisions: {focus_text}. "
            f"The resulting structure should have approximately {target_vars} variables "
            f"and {target_cons} constraints. "
            "Preserve the rest of the structure but introduce shared constraints linking "
            "the expanded nodes back to the existing blocks."
            f"{similarity_hint}"
        )
        return self._llm_structure_from_seed(signature, goal, "llm_focus_blocks")

    def _strategy_llm_random_variation_single(self, signatures: Sequence[StructureSignature],
                                               similarity_target: str | None = None) -> StructureBlueprint:
        signature      = self._random_signature(signatures)
        target_vars    = self._sample_from_range(self.variable_range)
        target_cons    = self._sample_from_range(self.constraint_range)
        target_blocks  = self._sample_from_range(self.block_range)
        target_coupling = max(target_blocks - 1,
                              int(target_cons * self._sample_float_range(self.coupling_ratio)))
        similarity_hint = _similarity_hint(similarity_target)
        goal = (
            f"Design a novel blueprint inspired by the seed but with renamed variables, "
            f"approximately {target_vars} variables, {target_cons} constraints, "
            f"and {target_blocks} blocks with at least {target_coupling} inter-block coupling constraints. "
            "Mix deterministic and coupling constraints to mimic graph-guided randomness. "
            "Ensure the final block structure stays cleanly partitionable so downstream agents "
            "can split it into blocks without confusion. "
            "Prefer a different application domain from the seed to maximize diversity."
            f"{similarity_hint}"
        )
        return self._llm_structure_from_seed(signature, goal, "llm_random_variation")

    def _llm_structure_from_seed(
        self,
        signature: StructureSignature,
        goal: str,
        strategy_name: str,
    ) -> StructureBlueprint:
        if not self.llm_client:
            raise StrategyError(
                "LLM client is not configured for LLM-based strategies")
        seed_payload = {
            "signature_id": signature.signature_id,
            "domain_hint": signature.metadata.get("domain", "operations"),
            "structure": signature.structure.to_dict(),
            "num_blocks": signature.num_blocks,
            "coupling_constraints": signature.coupling_constraints,
        }
        seed_json = json.dumps(seed_payload, ensure_ascii=False, indent=2)
        prompt = LLM_STRUCTURE_PROMPT.format(goal=goal, seed_json=seed_json)
        try:
            response = self.llm_client.generate(
                prompt, system_prompt=self.system_prompt) 
        except Exception as exc: 
            raise StrategyError(f"LLM call failed: {exc}") from exc
        cleaned = normalize_json_response(response)
        try:
            data = json.loads(cleaned)
        except json.JSONDecodeError as exc:
            raise StrategyError(
                f"LLM response is not valid JSON: {exc}") from exc

        structure_payload = data.get("structure")
        if not isinstance(structure_payload, dict):
            raise StrategyError("LLM response missing 'structure' object")
        vc_graph = structure_payload.get("variable_constraint_graph")
        if not isinstance(vc_graph, dict) or not vc_graph:
            raise StrategyError(
                "LLM response missing variable_constraint_graph data")

        variables = structure_payload.get("variables")
        constraints = structure_payload.get("constraints")
        if not variables or not constraints:
            raise StrategyError(
                "LLM response must include variables and constraints")

        structure = ProblemStructure(
            variables=variables,
            constraints=constraints,
            variable_constraint_graph=vc_graph,
            problem_type=structure_payload.get(
                "problem_type", signature.structure.problem_type),
            domain=structure_payload.get("domain", signature.structure.domain),
        )
        structure.ensure_graphs()

        used_vars = {v for vs in vc_graph.values() for v in vs}
        unused = [v for v in variables if v not in used_vars]
        if unused and constraints:
            for var in unused:
                chosen = self.rng.choice(constraints)
                vc_graph[chosen] = sorted(set(vc_graph.get(chosen, []) + [var]))
            structure = ProblemStructure(
                variables=variables,
                constraints=constraints,
                variable_constraint_graph=vc_graph,
                problem_type=structure.problem_type,
                domain=structure.domain,
            )
            structure.ensure_graphs()
        blueprint = StructureBlueprint(
            name=data.get("name", f"{strategy_name}_{self._unique_suffix()}"),
            structure=structure,
            domain_hint=data.get(
                "domain_hint", signature.metadata.get("domain", "operations")),
            decomposition={
                "mode": strategy_name,
                "strategy": strategy_name,
                "note": data.get("note", goal),
                "goal": goal,
            },
            source_signature_ids=[signature.signature_id],
        )
        return self._finalize_blueprint(blueprint, annotate=True)

    def _annotate_with_llm(self, blueprint: StructureBlueprint) -> None:
        if not self.llm_client:
            return
        summary = {
            "name": blueprint.name,
            "variables": blueprint.structure.variables,
            "constraints": blueprint.structure.constraints,
            "variable_constraint_graph": blueprint.structure.variable_constraint_graph,
            "mode": blueprint.decomposition.get("mode"),
        }
        prompt_template = dedent(
            """
            Suggest a concise domain label and decomposition insight for the following blueprint.
            Respond with EXACTLY one JSON object using double quotes and the keys "domain_hint" and "note".
            Do not wrap the JSON in markdown fences or add commentary. The object must parse via json.loads without any cleanup.
            Example output: {"domain_hint": "regional rail logistics", "note": "Two production blocks share a capacity coupling"}.
            Please follow that template verbatim, changing only the text values.
            """
        ).strip()
        prompt = prompt_template + "\n" + \
            json.dumps(summary, ensure_ascii=False)
        try:
            response = self.llm_client.generate(
                prompt, system_prompt=self.system_prompt)
            cleaned = normalize_json_response(response)
            data = json.loads(cleaned)
            blueprint.domain_hint = data.get(
                "domain_hint", blueprint.domain_hint)
            blueprint.decomposition["llm_note"] = data.get("note", cleaned)
        except json.JSONDecodeError:
            blueprint.decomposition["llm_note"] = response.strip()
        except Exception as exc: 
            blueprint.decomposition["llm_note"] = f"LLM annotation failed: {exc}"

    def _validate_blueprint(self, blueprint: StructureBlueprint) -> None:
        ensure_valid_structure(
            blueprint.structure,
            context=f"designer:{blueprint.name}",
        )
