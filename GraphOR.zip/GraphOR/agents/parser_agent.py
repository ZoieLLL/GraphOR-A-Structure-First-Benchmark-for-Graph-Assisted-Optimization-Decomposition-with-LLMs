from __future__ import annotations

import itertools
import json
from textwrap import dedent
from typing import List, Optional

from utils.data_models import ProblemStructure, StructureSignature
from utils.graph_utils import compute_block_assignments
from utils.prompt_utils import normalize_json_response
from utils.io_utils import read_jsonl
from utils.llm_client import BaseLLMClient
from utils.validation import ensure_valid_structure


class ParserAgent:
    def __init__(
        self,
        seed_path: str,
        llm_client: Optional[BaseLLMClient] = None,
        system_prompt: str | None = None,
    ):
        self.seed_path = seed_path
        self.llm_client = llm_client
        self.system_prompt = system_prompt or (
            "You summarize optimization problem structures for downstream agents."
        )

    def run(self) -> List[StructureSignature]:
        signatures: List[StructureSignature] = []
        counter = itertools.count(1)
        for record in read_jsonl(self.seed_path):
            structure = ProblemStructure(
                variables=record["structure"]["variables"],
                constraints=record["structure"]["constraints"],
                variable_constraint_graph=record["structure"]["variable_constraint_graph"],
                variable_connection_graph=record["structure"].get(
                    "variable_connection_graph"),
                constraint_connection_graph=record["structure"].get(
                    "constraint_connection_graph"),
                objective_variables=record["structure"].get(
                    "objective_variables"),
                problem_type=record["structure"].get(
                    "problem_type", "unknown"),
                domain=record["structure"].get("domain", "unspecified"),
            )
            structure.ensure_graphs()
            ensure_valid_structure(
                structure, context=record.get("question", "seed")
            )
            num_blocks, assignments, coupling = compute_block_assignments(
                structure)
            signature = StructureSignature(
                signature_id=f"sig_{next(counter)}",
                structure=structure,
                num_blocks=num_blocks,
                block_assignments=assignments,
                coupling_constraints=coupling,
                metadata={
                    "source_question": record.get("question"),
                    "problem_type": structure.problem_type,
                    "domain": structure.domain,
                    "decomposition": record.get("meta", {}).get("decomposition"),
                },
            )
            if self.llm_client:
                summary = self._summarize_structure(
                    structure, record.get("question", ""))
                signature.metadata["llm_summary"] = summary
            signatures.append(signature)
        return signatures

    def _summarize_structure(self, structure: ProblemStructure, question: str) -> str:
        summary_payload = {
            "question": question,
            "variables": structure.variables,
            "constraints": structure.constraints,
            "variable_constraint_graph": structure.variable_constraint_graph,
            "problem_type": structure.problem_type,
            "domain": structure.domain,
        }
        prompt_template = dedent(
            """
            Given the following structured optimization problem, describe the decomposition characteristics,
            potential block structure, and coupling edges. Respond with EXACTLY one JSON object that matches
            this schema: {{"summary": string (2 concise sentences), "highlights": [string, ...]}}.
            The array should list at most three short bullet phrases. Do not include markdown fences, prose before/after,
            or any additional keys. The JSON must parse via json.loads without modification.
            Example output: {{"summary": "Blocks decouple by corridors while c3 couples flows", "highlights": ["Two rail corridors", "Shared capacity at c3"]}}.
            Please copy this template and replace the text with the specifics of the provided structure.
            """
        ).strip()
        prompt = prompt_template + "\n" + \
            json.dumps(summary_payload, ensure_ascii=False)
        try:
            response = self.llm_client.generate(
                prompt, system_prompt=self.system_prompt)
            cleaned = normalize_json_response(response)
            data = json.loads(cleaned)
            summary = str(data.get("summary", "")).strip()
            highlights = data.get("highlights")
            highlight_text = ""
            if isinstance(highlights, list) and highlights:
                highlight_text = " Highlights: " + "; ".join(
                    str(item).strip() for item in highlights if item
                )
            combined = (summary + highlight_text).strip()
            return combined or summary or cleaned.strip()
        except (json.JSONDecodeError, TypeError):
            return response.strip()
        except Exception as exc:
            return f"LLM summary unavailable ({exc})"
