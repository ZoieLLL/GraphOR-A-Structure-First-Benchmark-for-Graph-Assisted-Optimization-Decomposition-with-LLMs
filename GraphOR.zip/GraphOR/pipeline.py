from __future__ import annotations

import argparse
import json
import hashlib
from datetime import datetime
from pathlib import Path
from typing import List

import yaml


_HERE = Path(__file__).parent.resolve()
from agents.parser_agent import ParserAgent
from agents.designer_agent import DesignerAgent
from agents.content_agent import ContentAgent
from agents.verifier_agent import VerifierAgent
from utils.io_utils import append_jsonl
from utils.llm_client import create_llm_client, BaseLLMClient, RetryLLMClient, FallbackLLMClient


def load_config(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _deep_update(target: dict, overrides: dict) -> dict:
    for key, value in overrides.items():
        if isinstance(value, dict) and isinstance(target.get(key), dict):
            _deep_update(target[key], value)
        else:
            target[key] = value
    return target


def _load_strategy_overrides(payload: str) -> dict:
    candidate = Path(payload)
    data: dict | None = None
    if candidate.exists():
        text = candidate.read_text(encoding="utf-8")
        if candidate.suffix.lower() in {".yaml", ".yml"}:
            loaded = yaml.safe_load(text)
        else:
            loaded = json.loads(text)
        if isinstance(loaded, dict):
            data = loaded
    else:
        try:
            parsed = json.loads(payload)
        except json.JSONDecodeError as exc:
            raise ValueError(
                f"Strategy override JSON is invalid: {exc}") from exc
        if isinstance(parsed, dict):
            data = parsed
    if data is None:
        raise ValueError(
            "Strategy overrides must resolve to a JSON/YAML object")
    return data


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate decomposable problems via multi-agent pipeline")
    parser.add_argument(
        "--config", default=str(_HERE / "config/settings.yaml"), help="Path to YAML config")
    parser.add_argument(
        "--seeds", help="Path to seed JSONL file", default=None)
    parser.add_argument("--mode", help="Designer mode override", default=None)
    parser.add_argument("--scale-factor", type=int,
                        default=None, dest="scale_factor")
    parser.add_argument(
        "--structures",
        type=int,
        default=None,
        help="Number of blueprints/structures to create",
    )
    parser.add_argument(
        "--problems",
        type=int,
        default=None,
        help="Number of full problems (structure + math + narrative) to generate",
    )
    parser.add_argument("--llm-backend", default=None, dest="llm_backend")
    parser.add_argument("--llm-model", default=None, dest="llm_model")
    parser.add_argument(
        "--skip-llm",
        action="store_true",
        help="Disable all external LLM calls by switching agents to mock backends",
    )
    parser.add_argument(
        "--strategy-overrides",
        default=None,
        help="JSON string or path to YAML/JSON file overriding generation.strategy",
    )
    parser.add_argument(
        "--no-cache",
        action="store_true",
        help="Ignore parser cache and re-parse seeds from scratch",
    )
    parser.add_argument(
        "--resume-from-ob",
        default=None,
        dest="resume_from_ob",
        help="Path to a previous output_ob run directory; skips parser+designer and loads blueprints from its designer.json",
    )
    return parser.parse_args()


def build_agent_llm(config: dict, agent_name: str) -> tuple[BaseLLMClient, str | None]:
    llm_root = config.get("llm", {})
    agent_conf = llm_root.get(agent_name, {})
    backend = agent_conf.get("backend")
    model = agent_conf.get("model")
    api_key = agent_conf.get("api_key")
    api_keys = agent_conf.get("api_keys")
    profiles = agent_conf.get("profiles")
    system_prompt = agent_conf.get("system_prompt")
    timeout = llm_root.get("timeout", 60.0)
    retries = int(llm_root.get("retries", 2))
    backoff = float(llm_root.get("retry_backoff_sec", 1.0))
    clients: List[BaseLLMClient] = []
    if isinstance(profiles, list) and profiles:
        for profile in profiles:
            if not isinstance(profile, dict):
                continue
            p_backend = profile.get("backend", backend)
            p_model = profile.get("model", model)
            p_key = profile.get("api_key", api_key)
            p_base_url = profile.get("base_url")
            p_timeout = float(profile.get("timeout", timeout))
            base_client = create_llm_client(
                p_backend,
                p_model,
                p_key,
                p_timeout,
                base_url=p_base_url,
            )
            clients.append(
                RetryLLMClient(
                    base_client,
                    name=agent_name,
                    retries=retries,
                    backoff_sec=backoff,
                )
            )
    else:
        key_list: List[str | None]
        if isinstance(api_keys, list) and api_keys:
            key_list = [str(item) for item in api_keys]
        else:
            key_list = [api_key]
        for key in key_list:
            base_client = create_llm_client(backend, model, key, timeout)
            clients.append(
                RetryLLMClient(
                    base_client,
                    name=agent_name,
                    retries=retries,
                    backoff_sec=backoff,
                )
            )

    client: BaseLLMClient
    if len(clients) == 1:
        client = clients[0]
    else:
        client = FallbackLLMClient(clients, name=agent_name)
    return client, system_prompt


def init_observation_dir(paths_cfg: dict) -> Path:
    root = _HERE / paths_cfg.get("observation_root", "output_ob")
    run_dir = root / datetime.now().strftime("%Y%m%d-%H%M%S")
    run_dir.mkdir(parents=True, exist_ok=True)
    import os
    os.environ["DATA_GENERATION_RUN_DIR"] = str(run_dir)
    return run_dir


def record_observation(run_dir: Path, agent: str, payload: dict) -> None:
    path = run_dir / f"{agent}.json"
    path.write_text(json.dumps(payload, ensure_ascii=False,
                    indent=2), encoding="utf-8")


def _seed_cache_key(seed_path: Path) -> str:
    content = seed_path.read_bytes()
    return hashlib.sha256(content).hexdigest()[:16]


def _parser_cache_path(seed_path: Path) -> Path:
    key = _seed_cache_key(seed_path)
    return _HERE / "data" / "cache" / f"parser_{key}.json"


def _save_parser_cache(seed_path: Path, signatures_data: list) -> None:
    cache_path = _parser_cache_path(seed_path)
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    cache_path.write_text(
        json.dumps({"seed_hash": _seed_cache_key(seed_path),
                    "signatures": signatures_data}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def _load_parser_cache(seed_path: Path):
    cache_path = _parser_cache_path(seed_path)
    if not cache_path.exists():
        return None
    try:
        data = json.loads(cache_path.read_text(encoding="utf-8"))
        if data.get("seed_hash") != _seed_cache_key(seed_path):
            return None
        return data.get("signatures")
    except Exception:
        return None


def _signatures_from_cache(cached_list: list):
    from utils.data_models import ProblemStructure, StructureSignature
    signatures = []
    for item in cached_list:
        s = item["structure"]
        structure = ProblemStructure(
            variables=s["variables"],
            constraints=s["constraints"],
            variable_constraint_graph=s["variable_constraint_graph"],
            variable_connection_graph=s.get("variable_connection_graph"),
            constraint_connection_graph=s.get("constraint_connection_graph"),
            objective_variables=s.get("objective_variables"),
            problem_type=s.get("problem_type", "unknown"),
            domain=s.get("domain", "unspecified"),
            integer_variables=s.get("integer_variables"),
        )
        structure.ensure_graphs()
        signatures.append(StructureSignature(
            signature_id=item["signature_id"],
            structure=structure,
            num_blocks=item["num_blocks"],
            block_assignments=item["block_assignments"],
            coupling_constraints=item["coupling_constraints"],
            metadata=item.get("metadata", {}),
        ))
    return signatures

def _blueprint_cache_path(seed_path: Path, blueprint_count: int) -> Path:
    key = _seed_cache_key(seed_path)
    return _HERE / "data" / "cache" / f"blueprints_{key}_n{blueprint_count}.jsonl"


def _load_blueprint_cache(
    seed_path: Path, blueprint_count: int
) -> list:
    cache_path = _blueprint_cache_path(seed_path, blueprint_count)
    if not cache_path.exists():
        return []
    try:
        results = []
        for line in cache_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line:
                results.append(json.loads(line))
        return results
    except Exception:
        return []


def _append_blueprint_cache(seed_path: Path, blueprint_count: int, bp_dict: dict) -> None:
    cache_path = _blueprint_cache_path(seed_path, blueprint_count)
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    with cache_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(bp_dict, ensure_ascii=False) + "\n")


def _clear_blueprint_cache(seed_path: Path, blueprint_count: int) -> None:
    cache_path = _blueprint_cache_path(seed_path, blueprint_count)
    if cache_path.exists():
        cache_path.unlink()



def _content_cache_key(problem_blueprints: list) -> str:
    names = "".join(bp.name for bp in problem_blueprints)
    return hashlib.sha256(names.encode()).hexdigest()[:16]


def _content_cache_path(problem_blueprints: list) -> Path:
    key = _content_cache_key(problem_blueprints)
    return _HERE / "data" / "cache" / f"content_{key}.jsonl"


def _load_content_cache(problem_blueprints: list) -> list:
    cache_path = _content_cache_path(problem_blueprints)
    if not cache_path.exists():
        return []
    try:
        results = []
        for line in cache_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line:
                results.append(json.loads(line))
        return results
    except Exception:
        return []


def _append_content_cache(problem_blueprints: list, problem_dict: dict) -> None:
    cache_path = _content_cache_path(problem_blueprints)
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    with cache_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(problem_dict, ensure_ascii=False) + "\n")


def _clear_content_cache(problem_blueprints: list) -> None:
    cache_path = _content_cache_path(problem_blueprints)
    if cache_path.exists():
        cache_path.unlink()


def _run_content_and_verifier(
    args,
    config: dict,
    observation_dir: Path,
    signatures: list,
    problem_blueprints: list,
) -> None:
    from utils.data_models import GeneratedProblem as _GP

    seed_hints = {
        sig.signature_id: {
            "question": sig.metadata.get("source_question"),
            "summary": sig.metadata.get("llm_summary"),
            "problem_type": sig.structure.problem_type,
            "integer_variables": sig.structure.integer_variables,
        }
        for sig in signatures
    }
    gen_cfg = config["generation"]
    math_attempts = gen_cfg.get("math_attempts", gen_cfg.get("question_attempts", 3))
    question_attempts = gen_cfg.get("question_attempts", 3)
    problem_type_config = gen_cfg.get("problem_type_distribution", {})
    free_gen_ratio = gen_cfg.get("free_gen_ratio", 0.5)

    print("[pipeline] Generating content...")
    content_llm, content_system = build_agent_llm(config, "content")
    content_agent = ContentAgent(
        llm_client=content_llm,
        system_prompt=content_system,
        seed_hints=seed_hints,
        max_math_attempts=math_attempts,
        max_question_attempts=question_attempts,
        problem_type_config=problem_type_config,
        free_gen_ratio=free_gen_ratio,
    )

    outputs_path = _HERE / config["paths"]["generated_file"]
    low_dir = outputs_path.parent / "generated_low"
    low_dir.mkdir(parents=True, exist_ok=True)
    low_path = low_dir / "generated_low.jsonl"
    outputs_path.parent.mkdir(parents=True, exist_ok=True)

    def _gp_from_dict(d: dict) -> "_GP":
        from utils.data_models import ProblemStructure as _PS2
        s = d["structure"]
        structure = _PS2(
            variables=s["variables"],
            constraints=s["constraints"],
            variable_constraint_graph=s["variable_constraint_graph"],
            variable_connection_graph=s.get("variable_connection_graph"),
            constraint_connection_graph=s.get("constraint_connection_graph"),
            objective_variables=s.get("objective_variables"),
            problem_type=s.get("problem_type", "unknown"),
            domain=s.get("domain", "unspecified"),
            integer_variables=s.get("integer_variables"),
        )
        structure.ensure_graphs()
        return _GP(
            question=d["question"],
            structure=structure,
            constraint_definitions=d["constraint_definitions"],
            objective_function=d["objective_function"],
            meta=d.get("meta", {}),
        )

    cached_problem_dicts = [] if args.no_cache else _load_content_cache(problem_blueprints)
    if cached_problem_dicts:
        print(f"[pipeline] Content cache: {len(cached_problem_dicts)} problems already saved "
              f"(need {len(problem_blueprints)}).")
    existing_problems = [_gp_from_dict(d) for d in cached_problem_dicts]

    def _on_problem(p: "_GP") -> None:
        _append_content_cache(problem_blueprints, p.to_dict())

    problems = content_agent.run(problem_blueprints, existing=existing_problems,
                                 on_problem=_on_problem)
    _clear_content_cache(problem_blueprints)

    record_observation(
        observation_dir,
        "content",
        {
            "input": {"blueprints": [bp.to_dict() for bp in problem_blueprints]},
            "output": {"problems": [p.to_dict() for p in problems]},
        },
    )

    print("[pipeline] Verifying problems...")
    verifier_llm, verifier_system = build_agent_llm(config, "verifier")
    verifier = VerifierAgent(llm_client=verifier_llm, system_prompt=verifier_system)
    verified_problems = verifier.run(problem_blueprints, problems)

    record_observation(
        observation_dir,
        "verifier",
        {
            "input": {
                "blueprints": [bp.to_dict() for bp in problem_blueprints],
                "problems": [p.to_dict() for p in problems],
            },
            "output": {
                "verified": [p.to_dict() for p in verified_problems],
                "report": verifier.report(),
            },
        },
    )



    print("[pipeline] Writing outputs...")
    append_jsonl(outputs_path, [p.to_dict() for p in verified_problems])

    fallback_problems = [p for p in problems if p.meta.get("generated_via") == "fallback"]
    if fallback_problems:
        append_jsonl(low_path, [p.to_dict() for p in fallback_problems])

    verified_type_stats = _build_type_stats(verified_problems)
    all_type_stats = _build_type_stats(problems)
    math_val_counts: dict = {}
    for p in verified_problems:
        status = p.meta.get("math_validation", {}).get("status", "unknown")
        math_val_counts[status] = math_val_counts.get(status, 0) + 1

    report = {
        "requested_blueprints":  len(problem_blueprints),
        "problem_blueprints":    len(problem_blueprints),
        "generated_total":       len(problems),
        "verified_samples":      len(verified_problems),
        "fallback_count":        len(fallback_problems),
        "problem_type_distribution": {
            "verified":  verified_type_stats,
            "all_generated": all_type_stats,
        },
        "math_validation_summary": math_val_counts,
        "failures": verifier.report(),
    }
    report_path = _HERE / config["paths"]["reports_file"]
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"Generated {len(verified_problems)} problems. Report saved to {report_path}.")
    if fallback_problems:
        print(f"  ({len(fallback_problems)} fallback problems saved to {low_path})")
    print(f"  Type distribution (verified): {verified_type_stats}")


def _build_type_stats(problems: list) -> dict:
    counts: dict = {}
    for p in problems:
        ptype = p.structure.problem_type or "unknown"
        counts[ptype] = counts.get(ptype, 0) + 1
    return counts


def _count_fallbacks(problems: list) -> int:
    return sum(1 for p in problems
               if p.meta.get("generated_via") == "fallback")


def main() -> None:
    args = parse_args()
    config = load_config(Path(args.config))

    if args.skip_llm:
        llm_cfg = config.setdefault("llm", {})
        for agent_name in ("parser", "designer", "content", "verifier"):
            llm_cfg.setdefault(agent_name, {})
            llm_cfg[agent_name]["backend"] = "mock"

    if args.strategy_overrides:
        try:
            overrides = _load_strategy_overrides(args.strategy_overrides)
        except ValueError as exc:
            raise SystemExit(
                f"Failed to load strategy overrides: {exc}") from exc
        generation_cfg = config.setdefault("generation", {})
        strategy_cfg = generation_cfg.setdefault("strategy", {})
        _deep_update(strategy_cfg, overrides)

    seed_path = Path(args.seeds) if args.seeds else (
        _HERE / config["paths"]["seeds"])
    designer_mode = (args.mode or config["generation"]["mode"]).lower()
    manual_scale_factor = args.scale_factor
    scale_factor = manual_scale_factor or config["generation"].get(
        "scale_factor", 1)
    blueprint_count = args.structures or config["generation"].get(
        "blueprint_count", 5)
    problem_target = args.problems
    if problem_target is None:
        problem_target = config["generation"].get("problem_count")
    observation_dir = init_observation_dir(config["paths"])

    if args.llm_backend or args.llm_model:
        config.setdefault("llm", {}).setdefault("content", {})
        if args.llm_backend:
            config["llm"]["content"]["backend"] = args.llm_backend
        if args.llm_model:
            config["llm"]["content"]["model"] = args.llm_model

    if args.resume_from_ob:
        ob_dir = Path(args.resume_from_ob)
        designer_ob = ob_dir / "designer.json"
        if not designer_ob.exists():
            raise SystemExit(f"[pipeline] --resume-from-ob: designer.json not found in {ob_dir}")
        ob_data = json.loads(designer_ob.read_text(encoding="utf-8"))
        from utils.data_models import StructureBlueprint as _BP, ProblemStructure as _PS
        def _bp_from_dict(d: dict) -> "_BP":
            s = d["structure"]
            structure = _PS(
                variables=s["variables"],
                constraints=s["constraints"],
                variable_constraint_graph=s["variable_constraint_graph"],
                variable_connection_graph=s.get("variable_connection_graph"),
                constraint_connection_graph=s.get("constraint_connection_graph"),
                objective_variables=s.get("objective_variables"),
                problem_type=s.get("problem_type", "unknown"),
                domain=s.get("domain", "unspecified"),
                integer_variables=s.get("integer_variables"),
            )
            structure.ensure_graphs()
            return _BP(
                name=d.get("name", "cached"),
                structure=structure,
                domain_hint=d.get("domain_hint", ""),
                decomposition=d.get("decomposition", {}),
                source_signature_ids=d.get("source_signature_ids", []),
            )
        blueprints = [_bp_from_dict(d) for d in ob_data["output"]["blueprints"]]
        print(f"[pipeline] Loaded {len(blueprints)} blueprints from {ob_dir} (skipping parser+designer).")

        parser_ob = ob_dir / "parser.json"
        signatures = []
        if parser_ob.exists():
            p_data = json.loads(parser_ob.read_text(encoding="utf-8"))
            signatures = _signatures_from_cache(p_data["output"]["signatures"])

        ob_problem_limit = ob_data.get("input", {}).get("problem_limit")
        if problem_target is None and ob_problem_limit is not None:
            problem_target = ob_problem_limit
            print(f"[pipeline] Using problem_limit={problem_target} from ob designer.json.")

        problem_blueprints = blueprints
        if problem_target is not None:
            if problem_target <= len(blueprints):
                problem_blueprints = blueprints[:problem_target]
            else:
                import random as _random
                _resample_seed = int(hashlib.sha256(
                    "".join(bp.name for bp in blueprints).encode()
                ).hexdigest()[:8], 16)
                _rng = _random.Random(_resample_seed)
                extra = problem_target - len(blueprints)
                sampled = _rng.choices(blueprints, k=extra)
                problem_blueprints = blueprints + sampled
                print(f"[pipeline] problem_target={problem_target} > blueprints={len(blueprints)}, "
                      f"resampling {extra} blueprints (seed={_resample_seed}).")

        _run_content_and_verifier(
            args, config, observation_dir, signatures, problem_blueprints,
        )
        return
    print("[pipeline] Parsing seeds...")
    signatures = None
    cached_list = None if args.no_cache else _load_parser_cache(seed_path)
    if cached_list is not None:
        print(
            f"[pipeline] Parser cache hit ({len(cached_list)} signatures), skipping LLM calls.")
        signatures = _signatures_from_cache(cached_list)
    else:
        parser_llm, parser_system = build_agent_llm(config, "parser")
        if args.skip_llm:
            parser_llm = None
        parser_agent = ParserAgent(
            seed_path,
            llm_client=parser_llm,
            system_prompt=parser_system,
        )
        signatures = parser_agent.run()
        _save_parser_cache(seed_path, [sig.to_dict() for sig in signatures])
        print(f"[pipeline] Parser cache saved ({len(signatures)} signatures).")

    record_observation(
        observation_dir,
        "parser",
        {
            "input": {"seed_path": str(seed_path)},
            "output": {"signatures": [sig.to_dict() for sig in signatures]},
        },
    )

    if not signatures:
        raise SystemExit("No signatures parsed from seeds")

    print("[pipeline] Designing blueprints...")
    designer_llm, designer_system = build_agent_llm(config, "designer")
    gen_cfg = config["generation"]
    strategy_config = dict(gen_cfg.get("strategy", {}))
    strategy_config["diversity"] = gen_cfg.get("diversity", {})
    designer = DesignerAgent(
        mode=designer_mode,
        scale_factor=scale_factor,
        blueprint_count=blueprint_count,
        llm_client=designer_llm,
        system_prompt=designer_system,
        manual_scale_factor=manual_scale_factor,
        strategy_config=strategy_config,
    )



    from utils.data_models import StructureBlueprint as _BP, ProblemStructure as _PS
    cached_bp_dicts = [] if args.no_cache else _load_blueprint_cache(seed_path, blueprint_count)
    if cached_bp_dicts:
        print(f"[pipeline] Blueprint cache: {len(cached_bp_dicts)} blueprints already saved "
              f"(need {blueprint_count}).")

    def _bp_from_dict(d: dict) -> "_BP":
        s = d["structure"]
        structure = _PS(
            variables=s["variables"],
            constraints=s["constraints"],
            variable_constraint_graph=s["variable_constraint_graph"],
            variable_connection_graph=s.get("variable_connection_graph"),
            constraint_connection_graph=s.get("constraint_connection_graph"),
            objective_variables=s.get("objective_variables"),
            problem_type=s.get("problem_type", "unknown"),
            domain=s.get("domain", "unspecified"),
            integer_variables=s.get("integer_variables"),
        )
        structure.ensure_graphs()
        return _BP(
            name=d.get("name", "cached"),
            structure=structure,
            domain_hint=d.get("domain_hint", ""),
            decomposition=d.get("decomposition", {}),
            source_signature_ids=d.get("source_signature_ids", []),
        )

    existing_blueprints = [_bp_from_dict(d) for d in cached_bp_dicts]

    def _on_blueprint(bp: "_BP") -> None:
        _append_blueprint_cache(seed_path, blueprint_count, bp.to_dict())

    try:
        blueprints = designer.run(signatures, existing=existing_blueprints,
                                  on_blueprint=_on_blueprint)
    except Exception as exc:
        raise SystemExit(
            f"[pipeline] Designer failed to produce any blueprints: {exc}") from exc

    _clear_blueprint_cache(seed_path, blueprint_count)
    print(f"[pipeline] {len(blueprints)} blueprints designed.")

    problem_blueprints = blueprints
    if problem_target is not None:
        if problem_target <= len(blueprints):
            problem_blueprints = blueprints[: problem_target]
        else:
            import random as _random
            extra = problem_target - len(blueprints)
            sampled = _random.choices(blueprints, k=extra)
            problem_blueprints = blueprints + sampled
            print(f"[pipeline] problem_target={problem_target} > blueprints={len(blueprints)}, "
                  f"randomly resampling {extra} blueprints to fill the gap.")
    record_observation(
        observation_dir,
        "designer",
        {
            "input": {
                "signatures": [sig.to_dict() for sig in signatures],
                "mode": designer_mode,
                "scale_factor": scale_factor,
                "blueprint_count": blueprint_count,
                "problem_limit": problem_target,
            },
            "output": {"blueprints": [bp.to_dict() for bp in blueprints]},
        },
    )

    _run_content_and_verifier(
        args, config, observation_dir, signatures, problem_blueprints,
    )


if __name__ == "__main__":
    main()
