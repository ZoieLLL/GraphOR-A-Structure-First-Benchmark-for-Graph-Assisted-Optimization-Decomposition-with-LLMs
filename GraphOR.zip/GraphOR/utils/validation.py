

from __future__ import annotations

from typing import Any, Dict, Iterable, List, Tuple

from .data_models import GeneratedProblem, ProblemStructure


class ValidationError(Exception):
    """Raised when structural validation fails."""


_ALLOWED_EXTRA_CONSTRAINT_KEYS = {"bounds"}


def _duplicates(items: Iterable[str]) -> List[str]:
    seen = set()
    dupes: List[str] = []
    for item in items:
        if item in seen and item not in dupes:
            dupes.append(item)
        seen.add(item)
    return dupes


def validate_structure_payload(structure: Dict[str, Any]) -> List[str]:


    issues: List[str] = []
    variables = structure.get("variables") or []
    constraints = structure.get("constraints") or []
    vc_graph = structure.get("variable_constraint_graph") or {}
    objective_vars = structure.get("objective_variables")

    if not variables:
        issues.append("no variables declared")
    else:
        dupes = _duplicates(variables)
        if dupes:
            issues.append(f"duplicate variable names: {', '.join(dupes)}")

    if not constraints:
        issues.append("no constraints declared")
    else:
        dupes = _duplicates(constraints)
        if dupes:
            issues.append(f"duplicate constraint names: {', '.join(dupes)}")

    usage = {var: 0 for var in variables}
    for constraint, vars_in_constraint in vc_graph.items():
        if constraint not in constraints:
            issues.append(
                f"constraint '{constraint}' appears in graph but not in constraint list"
            )
        if not vars_in_constraint:
            issues.append(f"constraint '{constraint}' has empty variable list")
            continue
        for var in vars_in_constraint:
            if var not in usage:
                issues.append(
                    f"constraint '{constraint}' references unknown variable '{var}'"
                )
            else:
                usage[var] += 1

    for constraint in constraints:
        if constraint not in vc_graph:
            issues.append(
                f"constraint '{constraint}' missing from variable graph")

    unused = [var for var, count in usage.items() if count == 0]
    if unused:
        issues.append(
            "variables never used in any constraint: " +
            ", ".join(sorted(unused))
        )

    if objective_vars:
        invalid_obj = [var for var in objective_vars if var not in usage]
        if invalid_obj:
            issues.append(
                "objective variables outside declared set: "
                + ", ".join(invalid_obj)
            )

    return issues


def ensure_valid_structure(structure: ProblemStructure, context: str | None = None) -> None:

    structure.ensure_graphs()
    issues = validate_structure_payload(structure.to_dict())
    if issues:
        prefix = f"[{context}] " if context else ""
        raise ValidationError(prefix + "; ".join(issues))


def validate_constraint_alignment(
    structure: ProblemStructure,
    constraint_definitions: Dict[str, Any],
) -> List[str]:

    structure.ensure_graphs()
    issues: List[str] = []
    for constraint in structure.constraints:
        expr = constraint_definitions.get(constraint)
        if not isinstance(expr, str) or not expr.strip():
            issues.append(
                f"constraint '{constraint}' missing textual definition")
            continue
        vars_in_constraint = structure.variable_constraint_graph.get(
            constraint, [])
        missing = [var for var in vars_in_constraint if var not in expr]
        if missing:
            issues.append(
                f"constraint '{constraint}' definition missing variables: {', '.join(missing)}"
            )

    extras = [
        name
        for name in constraint_definitions.keys()
        if name not in structure.constraints and name not in _ALLOWED_EXTRA_CONSTRAINT_KEYS
    ]
    if extras:
        issues.append(
            "definitions contain unknown constraints: " +
            ", ".join(sorted(extras))
        )
    if "bounds" not in constraint_definitions:
        issues.append("bounds definition missing")
    return issues


def validate_objective_alignment(
    structure: ProblemStructure,
    objective_function: str,
) -> List[str]:
    structure.ensure_graphs()
    issues: List[str] = []
    if not isinstance(objective_function, str) or not objective_function.strip():
        issues.append("objective function missing")
        return issues
    target_vars = structure.objective_variables or structure.variables
    missing = [var for var in target_vars if var not in objective_function]
    if missing:
        issues.append(
            "objective function missing variables: " +
            ", ".join(sorted(missing))
        )
    return issues


def validate_problem_content(problem: GeneratedProblem) -> List[str]:

    structure_issues = validate_structure_payload(problem.structure.to_dict())
    constraint_issues = validate_constraint_alignment(
        problem.structure, problem.constraint_definitions
    )
    objective_issues = validate_objective_alignment(
        problem.structure, problem.objective_function
    )
    return structure_issues + constraint_issues + objective_issues


def verify_structure(problem: GeneratedProblem) -> Tuple[bool, List[str]]:
    errors = validate_problem_content(problem)
    return len(errors) == 0, errors


def compare_with_blueprint(
    blueprint: Dict[str, List[str]],
    problem: GeneratedProblem,
) -> Tuple[bool, List[str]]:
    errors: List[str] = []
    expected_vars = set(blueprint.get("variables", []))
    actual_vars = set(problem.structure.variables)
    if expected_vars != actual_vars:
        errors.append("variable set mismatch")
    expected_constraints = set(blueprint.get("constraints", []))
    actual_constraints = set(problem.structure.constraints)
    if expected_constraints != actual_constraints:
        errors.append("constraint set mismatch")
    exp_graph = blueprint.get("variable_constraint_graph", {})
    act_graph = problem.structure.variable_constraint_graph
    if exp_graph != act_graph:
        errors.append("variable-constraint graph mismatch")

    from .graph_utils import compute_block_assignments as _compute_blocks
    from .data_models import ProblemStructure as _PS

    problem.structure.ensure_graphs()
    prob_num_blocks, _prob_assignments, prob_coupling = _compute_blocks(
        problem.structure
    )

    bp_struct = _PS(
        variables=list(expected_vars),
        constraints=list(expected_constraints),
        variable_constraint_graph=dict(exp_graph),
    )
    bp_struct.ensure_graphs()
    bp_num_blocks, _bp_assignments, bp_coupling = _compute_blocks(bp_struct)

    if prob_num_blocks != bp_num_blocks:
        errors.append(
            f"block count mismatch: blueprint has {bp_num_blocks}, "
            f"problem has {prob_num_blocks}"
        )
    if set(prob_coupling) != set(bp_coupling):
        errors.append("coupling constraint set mismatch")

    return len(errors) == 0, errors
