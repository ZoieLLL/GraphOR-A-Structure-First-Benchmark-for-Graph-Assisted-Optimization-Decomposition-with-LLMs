from __future__ import annotations

from collections import Counter, defaultdict
from typing import Dict, List, Tuple

from utils.data_models import ProblemStructure

def graph_from_structure(structure: ProblemStructure) -> Dict[str, List[str]]:
    conn = getattr(structure, "variable_connection_graph", None) or {}
    if conn:

        adj: Dict[str, List[str]] = defaultdict(list)
        for v, neighbours in conn.items():
            for nb in neighbours:
                if nb != v:
                    adj[v].append(nb)
                    adj[nb].append(v)

        return {v: sorted(set(ns)) for v, ns in adj.items()}

    vc = getattr(structure, "variable_constraint_graph", None) or {}
    adj2: Dict[str, List[str]] = defaultdict(list)
    for _c, vars_in_c in vc.items():
        for i, vi in enumerate(vars_in_c):
            for vj in vars_in_c[i + 1:]:
                adj2[vi].append(vj)
                adj2[vj].append(vi)
    return {v: sorted(set(ns)) for v, ns in adj2.items()}

def _wl_labels(adj: Dict[str, List[str]],
               iterations: int) -> List[Counter]:
    nodes = list(adj.keys())
    labels: Dict[str, int] = {v: len(adj.get(v, [])) for v in nodes}
    for v, nbrs in adj.items():
        for nb in nbrs:
            if nb not in labels:
                labels[nb] = len(adj.get(nb, []))

    all_nodes = list(labels.keys())
    counters: List[Counter] = [Counter(labels.values())]

    label_map: Dict[Tuple, int] = {}
    next_label = max(labels.values()) + 1 if labels else 0

    for _ in range(iterations):
        new_labels: Dict[str, int] = {}
        for v in all_nodes:
            neighbour_labels = tuple(sorted(labels[nb]
                                            for nb in adj.get(v, [])
                                            if nb in labels))
            key = (labels[v], neighbour_labels)
            if key not in label_map:
                label_map[key] = next_label
                next_label += 1
            new_labels[v] = label_map[key]
        labels = new_labels
        counters.append(Counter(labels.values()))

    return counters


def _wl_feature_vector(counters: List[Counter]) -> Counter:
    merged: Counter = Counter()
    for it, cnt in enumerate(counters):
        for label, freq in cnt.items():
            merged[(it, label)] += freq
    return merged


def _cosine_similarity(a: Counter, b: Counter) -> float:
    keys = set(a.keys()) | set(b.keys())
    if not keys:
        return 1.0
    dot = sum(a.get(k, 0) * b.get(k, 0) for k in keys)
    norm_a = sum(v * v for v in a.values()) ** 0.5
    norm_b = sum(v * v for v in b.values()) ** 0.5
    if norm_a == 0 or norm_b == 0:
        return 1.0 if norm_a == norm_b == 0 else 0.0
    return dot / (norm_a * norm_b)


def wl_similarity(
    struct_a: ProblemStructure,
    struct_b: ProblemStructure,
    iterations: int = 3,
) -> float:
    adj_a = graph_from_structure(struct_a)
    adj_b = graph_from_structure(struct_b)
    counters_a = _wl_labels(adj_a, iterations)
    counters_b = _wl_labels(adj_b, iterations)
    vec_a = _wl_feature_vector(counters_a)
    vec_b = _wl_feature_vector(counters_b)
    return round(_cosine_similarity(vec_a, vec_b), 4)


def wl_similarity_to_signatures(
    structure: ProblemStructure,
    signatures,
    iterations: int = 3,
) -> float:
    if not signatures:
        return 0.0
    return max(
        wl_similarity(structure, sig.structure, iterations)
        for sig in signatures
    )
