from __future__ import annotations


def normalize_json_response(raw: str) -> str:
    text = raw.strip()
    if text.startswith("```"):
        segments = text.split("```")
        text = "".join(
            seg for seg in segments if "{" in seg and "}" in seg) or text
    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end != -1 and start <= end:
        return text[start: end + 1].strip()
    return text
