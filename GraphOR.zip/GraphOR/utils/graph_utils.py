
from __future__ import annotations

import random
from typing import Dict, List, Tuple, Optional

import networkx as nx

from .data_models import ProblemStructure


def build_variable_connections(var_constraint_graph: Dict[str, List[str]], variables: List[str]) -> Dict[str, List[str]]:
    connections = {var: set() for var in variables}
    for vars_in_constraint in var_constraint_graph.values():
        for i, var_i in enumerate(vars_in_constraint):
            for var_j in vars_in_constraint[i + 1:]:
                connections[var_i].add(var_j)
                connections[var_j].add(var_i)
    return {var: sorted(list(neigh)) for var, neigh in connections.items()}


def build_constraint_connections(var_constraint_graph: Dict[str, List[str]], constraints: List[str]) -> Dict[str, List[str]]:
    connections = {const: set() for const in constraints}
    for c_i in constraints:
        vars_i = set(var_constraint_graph.get(c_i, []))
        for c_j in constraints:
            if c_i >= c_j:
                continue
            vars_j = set(var_constraint_graph.get(c_j, []))
            if vars_i & vars_j:
                connections[c_i].add(c_j)
                connections[c_j].add(c_i)
    return {const: sorted(list(neigh)) for const, neigh in connections.items()}


def compute_block_assignments(structure: ProblemStructure) -> Tuple[int, Dict[str, int], List[str]]:
    structure.ensure_graphs()
    graph = nx.Graph()
    for var, neighbors in structure.variable_connection_graph.items(): 
        for neigh in neighbors:
            graph.add_edge(var, neigh)
        if not neighbors:
            graph.add_node(var)
    components = list(nx.connected_components(graph))
    assignments = {}
    for block_id, component in enumerate(components):
        for var in component:
            assignments[var] = block_id
    coupling_constraints = [
        constraint
        for constraint, vars_in_const in structure.variable_constraint_graph.items()
        if len({assignments.get(var, -1) for var in vars_in_const}) > 1
    ]
    return len(components), assignments, coupling_constraints


def scale_structure(
    structure: ProblemStructure,
    scale_factor: int,
    coupling_ratio: float = 0.10,
    rng: Optional[random.Random] = None,
) -> ProblemStructure:
    if scale_factor == 1:
        return structure

    if rng is None:
        rng = random.Random()

    structure.ensure_graphs()
    new_variables: List[str] = []
    new_constraints: List[str] = []
    new_vc_graph: Dict[str, List[str]] = {}

    block_vars: List[List[str]] = []  
    for scale_idx in range(scale_factor):
        suffix = f"_{scale_idx + 1}"
        var_mapping = {var: f"{var}{suffix}" for var in structure.variables}
        block_var_list = [var_mapping[v] for v in structure.variables]
        block_vars.append(block_var_list)
        new_variables.extend(block_var_list)
        for constraint in structure.constraints:
            name = f"{constraint}{suffix}"
            new_constraints.append(name)
            new_vc_graph[name] = [var_mapping[v]
                                  for v in structure.variable_constraint_graph[constraint]]
    n_coupling = max(scale_factor - 1,
                     int(len(new_constraints) * coupling_ratio))

    coupling_added = 0
    for pair_idx in range(scale_factor - 1):
        vars_left  = block_vars[pair_idx]
        vars_right = block_vars[pair_idx + 1]
        n_left  = rng.randint(1, min(2, len(vars_left)))
        n_right = rng.randint(1, min(2, len(vars_right)))
        coupled_vars = (rng.sample(vars_left,  n_left) +
                        rng.sample(vars_right, n_right))
        cname = f"coupling_{pair_idx + 1}_{pair_idx + 2}"
        new_constraints.append(cname)
        new_vc_graph[cname] = sorted(set(coupled_vars))
        coupling_added += 1

    extra_attempts = 0
    while coupling_added < n_coupling and extra_attempts < n_coupling * 4:
        extra_attempts += 1
        i, j = rng.sample(range(scale_factor), 2)
        if i == j:
            continue
        vars_i = block_vars[i]
        vars_j = block_vars[j]
        n_i = rng.randint(1, min(2, len(vars_i)))
        n_j = rng.randint(1, min(2, len(vars_j)))
        coupled_vars = rng.sample(vars_i, n_i) + rng.sample(vars_j, n_j)
        cname = f"coupling_extra_{coupling_added + 1}"
        if cname in new_vc_graph:
            continue
        new_constraints.append(cname)
        new_vc_graph[cname] = sorted(set(coupled_vars))
        coupling_added += 1

    scaled = ProblemStructure(
        variables=new_variables,
        constraints=new_constraints,
        variable_constraint_graph=new_vc_graph,
        problem_type=structure.problem_type,
        domain=structure.domain,
    )
    scaled.ensure_graphs()
    return scaled


def combine_structures(
    struct_a: ProblemStructure,
    struct_b: ProblemStructure,
    n_coupling: int = 2,
    rng: Optional[random.Random] = None,
) -> ProblemStructure:
    if rng is None:
        rng = random.Random()

    struct_a.ensure_graphs()
    struct_b.ensure_graphs()

    def tag(name: str, suffix: str) -> str:
        return f"{name}_{suffix}"

    vars_a = [tag(v, "a") for v in struct_a.variables]
    vars_b = [tag(v, "b") for v in struct_b.variables]
    variables = vars_a + vars_b

    constraints = (
        [tag(c, "a") for c in struct_a.constraints] +
        [tag(c, "b") for c in struct_b.constraints]
    )

    vc_graph: Dict[str, List[str]] = {}
    for c, vs in struct_a.variable_constraint_graph.items():
        vc_graph[tag(c, "a")] = [tag(v, "a") for v in vs]
    for c, vs in struct_b.variable_constraint_graph.items():
        vc_graph[tag(c, "b")] = [tag(v, "b") for v in vs]

    for k in range(max(1, n_coupling)):
        n_from_a = rng.randint(1, min(2, len(vars_a)))
        n_from_b = rng.randint(1, min(2, len(vars_b)))
        coupled = (rng.sample(vars_a, n_from_a) +
                   rng.sample(vars_b, n_from_b))
        cname = f"coupling_ab_{k + 1}"
        constraints.append(cname)
        vc_graph[cname] = sorted(set(coupled))

    combined = ProblemStructure(
        variables=variables,
        constraints=constraints,
        variable_constraint_graph=vc_graph,
        problem_type="MILP" if "MILP" in (struct_a.problem_type, struct_b.problem_type) else struct_a.problem_type,
        domain=f"{struct_a.domain}_{struct_b.domain}",
    )
    combined.ensure_graphs()
    return combined


def generate_sbm_structure(
    num_vars: int,
    num_constraints: int,
    num_blocks: int,
    coupling_ratio: float = 0.10,
    min_incidence: int = 2,
    max_incidence: int = 5,
    prefix: str = "sbm",
    rng: Optional[random.Random] = None,
) -> ProblemStructure:
    if rng is None:
        rng = random.Random()

    num_blocks  = max(2, num_blocks)
    num_vars    = max(num_blocks * 2, num_vars)

    variables   = [f"{prefix}_x{i}" for i in range(1, num_vars + 1)]
    constraints_list: List[str] = []
    vc_graph: Dict[str, List[str]] = {}
    block_var_lists: List[List[str]] = [[] for _ in range(num_blocks)]
    for i, var in enumerate(variables):
        block_var_lists[i % num_blocks].append(var)

    n_coupling    = max(num_blocks - 1, int(num_constraints * coupling_ratio))
    n_intra       = num_constraints - n_coupling

    for idx in range(n_intra):
        block_id  = idx % num_blocks
        block_vs  = block_var_lists[block_id]
        span      = min(rng.randint(min_incidence, max_incidence), len(block_vs))
        span      = max(1, span)
        chosen    = rng.sample(block_vs, span)
        cname     = f"{prefix}_c{idx + 1}"
        constraints_list.append(cname)
        vc_graph[cname] = sorted(chosen)

    coupling_idx = n_intra
    adjacent_pairs = [(i, i + 1) for i in range(num_blocks - 1)]
    covered_pairs  = set()
    for bi, bj in adjacent_pairs:
        vs_i   = block_var_lists[bi]
        vs_j   = block_var_lists[bj]
        n_i    = rng.randint(1, min(2, len(vs_i)))
        n_j    = rng.randint(1, min(2, len(vs_j)))
        chosen = rng.sample(vs_i, n_i) + rng.sample(vs_j, n_j)
        cname  = f"{prefix}_coup{coupling_idx + 1}"
        constraints_list.append(cname)
        vc_graph[cname] = sorted(set(chosen))
        covered_pairs.add((bi, bj))
        coupling_idx += 1

    extra_attempts = 0
    while coupling_idx < n_intra + n_coupling and extra_attempts < n_coupling * 6:
        extra_attempts += 1
        bi, bj = rng.sample(range(num_blocks), 2)
        if bi == bj:
            continue
        vs_i   = block_var_lists[bi]
        vs_j   = block_var_lists[bj]
        n_i    = rng.randint(1, min(2, len(vs_i)))
        n_j    = rng.randint(1, min(2, len(vs_j)))
        chosen = rng.sample(vs_i, n_i) + rng.sample(vs_j, n_j)
        cname  = f"{prefix}_coup{coupling_idx + 1}"
        if cname in vc_graph:
            continue
        constraints_list.append(cname)
        vc_graph[cname] = sorted(set(chosen))
        coupling_idx += 1

    used_vars = {v for vs in vc_graph.values() for v in vs}
    unused    = [v for v in variables if v not in used_vars]
    for var in unused:

        block_id = variables.index(var) % num_blocks
        candidates = [
            c for c in constraints_list
            if any(v in block_var_lists[block_id] for v in vc_graph.get(c, []))
            and var not in vc_graph.get(c, [])
        ]
        if candidates:
            chosen_c = rng.choice(candidates)
            vc_graph[chosen_c] = sorted(vc_graph[chosen_c] + [var])
        else:
            block_constraints = [
                c for c in constraints_list
                if any(v in block_var_lists[block_id] for v in vc_graph.get(c, []))
            ]
            if block_constraints:
                chosen_c = rng.choice(block_constraints)
                vc_graph[chosen_c] = sorted(vc_graph[chosen_c] + [var])

    structure = ProblemStructure(
        variables=variables,
        constraints=constraints_list,
        variable_constraint_graph=vc_graph,
        problem_type="synthetic",
        domain="sbm_synthesis",
    )
    structure.ensure_graphs()
    return structure
