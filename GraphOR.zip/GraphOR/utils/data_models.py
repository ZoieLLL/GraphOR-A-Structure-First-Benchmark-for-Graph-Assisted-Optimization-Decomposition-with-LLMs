
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any


@dataclass
class ProblemStructure:
    variables: List[str]
    constraints: List[str]
    variable_constraint_graph: Dict[str, List[str]]
    variable_connection_graph: Optional[Dict[str, List[str]]] = None
    constraint_connection_graph: Optional[Dict[str, List[str]]] = None
    objective_variables: Optional[List[str]] = None
    problem_type: str = "unknown"
    domain: str = "unspecified"
    integer_variables: Optional[List[str]] = None

    def ensure_graphs(self) -> None:
        from .graph_utils import build_variable_connections, build_constraint_connections

        if self.variable_connection_graph is None:
            self.variable_connection_graph = build_variable_connections(
                self.variable_constraint_graph, self.variables
            )
        if self.constraint_connection_graph is None:
            self.constraint_connection_graph = build_constraint_connections(
                self.variable_constraint_graph, self.constraints
            )
        if self.objective_variables is None:
            self.objective_variables = list(self.variables)

    def to_dict(self) -> Dict[str, Any]:
        self.ensure_graphs()
        result = {
            "variables": self.variables,
            "constraints": self.constraints,
            "variable_constraint_graph": self.variable_constraint_graph,
            "variable_connection_graph": self.variable_connection_graph,
            "constraint_connection_graph": self.constraint_connection_graph,
            "objective_variables": self.objective_variables,
            "problem_type": self.problem_type,
            "domain": self.domain,
        }
        if self.integer_variables:
            result["integer_variables"] = self.integer_variables
        return result


@dataclass
class StructureSignature:
    signature_id: str
    structure: ProblemStructure
    num_blocks: int
    block_assignments: Dict[str, int]
    coupling_constraints: List[str]
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "signature_id": self.signature_id,
            "structure": self.structure.to_dict(),
            "num_blocks": self.num_blocks,
            "block_assignments": self.block_assignments,
            "coupling_constraints": self.coupling_constraints,
            "metadata": self.metadata,
        }


@dataclass
class StructureBlueprint:
    name: str
    structure: ProblemStructure
    domain_hint: str
    decomposition: Dict[str, Any]
    source_signature_ids: List[str]

    def to_prompt_dict(self) -> Dict[str, Any]:
        payload = {
            "name": self.name,
            "domain_hint": self.domain_hint,
            "decomposition": self.decomposition,
            "variables": self.structure.variables,
            "constraints": self.structure.constraints,
            "variable_constraint_graph": self.structure.variable_constraint_graph,
            "objective_variables": self.structure.objective_variables,
            "problem_type": self.structure.problem_type,
            "domain": self.structure.domain,
        }
        if self.structure.variable_connection_graph:
            payload["variable_connection_graph"] = self.structure.variable_connection_graph
        if self.structure.constraint_connection_graph:
            payload["constraint_connection_graph"] = self.structure.constraint_connection_graph
        return payload

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "structure": self.structure.to_dict(),
            "domain_hint": self.domain_hint,
            "decomposition": self.decomposition,
            "source_signature_ids": self.source_signature_ids,
        }


@dataclass
class GeneratedProblem:
    question: str
    structure: ProblemStructure
    constraint_definitions: Dict[str, Any]
    objective_function: str
    meta: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        structure_dict = {
            "variables": self.structure.variables,
            "constraints": self.structure.constraints,
            "variable_constraint_graph": self.structure.variable_constraint_graph,
            "variable_connection_graph": self.structure.variable_connection_graph,
            "constraint_connection_graph": self.structure.constraint_connection_graph,
            "objective_variables": self.structure.objective_variables,
            "problem_type": self.structure.problem_type,
            "domain": self.structure.domain,
        }
        if self.structure.integer_variables:
            structure_dict["integer_variables"] = self.structure.integer_variables

        return {
            "question": self.question,
            "structure": structure_dict,
            "constraint_definitions": self.constraint_definitions,
            "objective_function": self.objective_function,
            "meta": self.meta,
        }
