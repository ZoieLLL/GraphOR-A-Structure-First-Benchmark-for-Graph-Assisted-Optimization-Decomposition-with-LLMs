from __future__ import annotations

import re
import time
from typing import Dict, List, Tuple, Any

import numpy as np
from scipy.optimize import linprog, minimize

_ZERO_TOL          = 1e-6
_VAR_TOL           = 1e-6
DEFAULT_TIME_LIMIT = 20.0

def detect_problem_type(problem: dict) -> str:
    type_str    = (problem.get("structure", {}).get("problem_type", "")
                   or problem.get("meta", {}).get("problem_type", "LP")).upper()
    has_integer = bool(detect_integer_vars(problem))
    has_quad    = detect_quadratic(problem)

    if has_integer and has_quad:
        return "MINLP"
    if has_integer or type_str in ("MIP", "MILP", "INTEGER"):
        return "MIP"
    if has_quad or type_str in ("QP", "NLP", "QCQP"):
        return "QP"
    if type_str == "MINLP":
        return "MINLP"
    return "LP"


def detect_integer_vars(problem: dict) -> List[str]:
    ivars = problem.get("structure", {}).get("integer_variables", [])
    if ivars:
        return list(ivars)
    ivars = problem.get("meta", {}).get("integer_variables", [])
    if ivars:
        return list(ivars)
    bounds_str = problem.get("constraint_definitions", {}).get("bounds", "")
    if "integer" in bounds_str.lower():
        found = re.findall(r'([a-zA-Z_]\w*)\s+integer', bounds_str, re.IGNORECASE)
        if found:
            return found
    return []


def detect_quadratic(problem: dict) -> bool:
    quad_pat = re.compile(
        r'[a-zA-Z_]\w*\s*\^\s*\d|[a-zA-Z_]\w*\s*\*\s*[a-zA-Z_]\w*')
    texts = [problem.get("objective_function", "")]
    for v in problem.get("constraint_definitions", {}).values():
        if isinstance(v, str):
            texts.append(v)
    return any(quad_pat.search(t) for t in texts)


def _parse_linear_expr(expr: str, var_idx: dict, n: int) -> np.ndarray:
    coef   = np.zeros(n)
    expr   = re.sub(r'(?i)(minimize|maximize)\s*', '', expr).strip()
    tokens = re.findall(r'([+-]?\s*[\d.]*\s*\*?\s*[a-zA-Z_]\w*)',
                        expr.replace(' ', ''))
    for token in tokens:
        token = token.replace(' ', '')
        if '*' in token:
            parts = token.split('*')
            try:
                val, vname = float(parts[0]), parts[1]
            except ValueError:
                val, vname = float(parts[1]), parts[0]
        else:
            m = re.match(r'^([+-]?\d*\.?\d*)([a-zA-Z_]\w*)$', token)
            if not m:
                continue
            coef_str, vname = m.group(1), m.group(2)
            val = 1.0 if coef_str in ('', '+') else (
                  -1.0 if coef_str == '-' else float(coef_str))
        if vname in var_idx:
            coef[var_idx[vname]] += val
    return coef


def _parse_constraint(cstr: str, var_idx: dict, n: int
                       ) -> Tuple[np.ndarray, float, str]:
    cstr = cstr.strip()
    if '<=' in cstr:
        lhs, rhs = cstr.split('<=', 1); ctype = 'leq'
    elif '>=' in cstr:
        lhs, rhs = cstr.split('>=', 1); ctype = 'geq'
    elif '==' in cstr:
        lhs, rhs = cstr.split('==', 1); ctype = 'eq'
    elif re.search(r'(?<![<>!])=(?!=)', cstr):
        lhs, rhs = re.split(r'(?<![<>!])=(?!=)', cstr, maxsplit=1); ctype = 'eq'
    else:
        raise ValueError(f"Cannot parse constraint: {cstr}")
    lhs_coef = _parse_linear_expr(lhs.strip(), var_idx, n)
    try:
        rhs_val = float(rhs.strip())
        row     = lhs_coef
    except ValueError:
        rhs_coef = _parse_linear_expr(rhs.strip(), var_idx, n)
        row      = lhs_coef - rhs_coef
        rhs_val  = 0.0
    return row, rhs_val, ctype


def parse_lp(problem: dict) -> dict:
    variables = problem["structure"]["variables"]
    var_idx   = {v: i for i, v in enumerate(variables)}
    n         = len(variables)

    obj_str = problem.get("objective_function", "")
    sense   = 1 if "minimize" in obj_str.lower() else -1
    c       = _parse_linear_expr(obj_str, var_idx, n) * sense

    cdef = problem.get("constraint_definitions", {})
    A_ub_rows, b_ub_vals = [], []
    A_eq_rows, b_eq_vals = [], []

    for cname, cstr in cdef.items():
        if cname == "bounds":
            continue
        row, rhs, ctype = _parse_constraint(cstr, var_idx, n)
        if ctype == "leq":
            A_ub_rows.append(row); b_ub_vals.append(rhs)
        elif ctype == "geq":
            A_ub_rows.append(-row); b_ub_vals.append(-rhs)
        else:
            A_eq_rows.append(row); b_eq_vals.append(rhs)

    A_ub = np.array(A_ub_rows, dtype=float) if A_ub_rows else np.zeros((0, n))
    b_ub = np.array(b_ub_vals, dtype=float) if b_ub_vals else np.zeros(0)
    A_eq = np.array(A_eq_rows, dtype=float) if A_eq_rows else np.zeros((0, n))
    b_eq = np.array(b_eq_vals, dtype=float) if b_eq_vals else np.zeros(0)

    integer_var_set = set(
        problem.get("structure", {}).get("integer_variables", [])
        + problem.get("meta", {}).get("integer_variables", [])
    )
    bounds_str = cdef.get("bounds", "").lower()
    if "binary" in bounds_str or "in {0,1}" in bounds_str or "∈ {0,1}" in bounds_str:
        binary_set = integer_var_set
    else:
        binary_set = set()
    bounds = [(0, 1) if v in binary_set else (0, None) for v in variables]

    return {
        "variables": variables,
        "var_idx":   var_idx,
        "c":         c,
        "sense":     sense,
        "A_ub": A_ub, "b_ub": b_ub,
        "A_eq": A_eq, "b_eq": b_eq,
        "bounds":    bounds,
    }


def _parse_quadratic_expr(expr: str, var_idx: dict, n: int) -> np.ndarray:
    Q         = np.zeros((n, n))
    expr      = re.sub(r'(?i)(minimize|maximize)\s*', '', expr).strip()
    sq_pat    = re.compile(r'([+-]?[\d.]*)\*?([a-zA-Z_]\w*)\^2')
    cross_pat = re.compile(r'([+-]?[\d.]*)\*?([a-zA-Z_]\w*)\*([a-zA-Z_]\w*)')
    for m in sq_pat.finditer(expr.replace(' ', '')):
        coef_str, vname = m.group(1), m.group(2)
        coef = 1.0 if coef_str in ('', '+') else (
               -1.0 if coef_str == '-' else float(coef_str))
        if vname in var_idx:
            Q[var_idx[vname], var_idx[vname]] += 2 * coef
    for m in cross_pat.finditer(expr.replace(' ', '')):
        coef_str, va, vb = m.group(1), m.group(2), m.group(3)
        if va == vb:
            continue
        coef = 1.0 if coef_str in ('', '+') else (
               -1.0 if coef_str == '-' else float(coef_str))
        if va in var_idx and vb in var_idx:
            i, j = var_idx[va], var_idx[vb]
            Q[i, j] += coef; Q[j, i] += coef
    return Q


def parse_qp(problem: dict) -> dict:
    obj_str    = problem.get("objective_function", "")
    obj_linear = re.sub(r'[+-]?\s*[\d.]*\s*\*?\s*[a-zA-Z_]\w*\s*\^\s*\d', '', obj_str)
    obj_linear = re.sub(r'[+-]?\s*[\d.]*\s*\*?\s*[a-zA-Z_]\w*\s*\*\s*[a-zA-Z_]\w*', '', obj_linear)
    prob_linear = dict(problem)
    prob_linear["objective_function"] = obj_linear.strip() or (
        "minimize 0" if "minimize" in obj_str.lower() else "maximize 0")
    lp  = parse_lp(prob_linear)
    n   = len(lp["variables"])
    Q   = _parse_quadratic_expr(obj_str, lp["var_idx"], n)
    if lp["sense"] == -1:
        Q = -Q
    lp["Q_obj"] = Q
    return lp


_ILL_COND_THRESHOLD = 1e12 


def _is_nonconvex_qp(lp: dict) -> bool:

    Q = lp.get("Q_obj")
    if Q is not None:
        try:
            if float(np.linalg.eigvalsh(Q).min()) < -1e-8:
                return True
        except Exception:
            pass
    if lp["A_eq"].size:
        try:
            if np.linalg.cond(lp["A_eq"]) > _ILL_COND_THRESHOLD:
                return True
        except Exception:
            pass
    return False


def _solve_nonconvex_qp_de(lp: dict, time_limit: float) -> dict:

    from scipy.optimize import differential_evolution, NonlinearConstraint
    n = len(lp["variables"])
    Q = lp.get("Q_obj", np.zeros((n, n)))
    c = lp["c"]

    def obj(x): return float(0.5 * x @ Q @ x + c @ x)

    lp_res = linprog(c=lp["c"],
                     A_ub=lp["A_ub"] if lp["A_ub"].size else None,
                     b_ub=lp["b_ub"] if lp["b_ub"].size else None,
                     A_eq=lp["A_eq"] if lp["A_eq"].size else None,
                     b_eq=lp["b_eq"] if lp["b_eq"].size else None,
                     bounds=lp["bounds"], method="highs")
    ref = lp_res.x if lp_res.success else np.zeros(n)
    scale = max(float(np.abs(ref).max()), 10.0) * 5.0
    de_bounds = []
    for i, (lo, hi) in enumerate(lp["bounds"]):
        lo_eff = lo if (lo is not None and lo > -1e9) else ref[i] - scale
        hi_eff = hi if (hi is not None and hi <  1e9) else ref[i] + scale
        if lo_eff >= hi_eff:
            hi_eff = lo_eff + 1.0
        de_bounds.append((lo_eff, hi_eff))

    constraints_de = []
    if lp["A_ub"].size:
        for i in range(lp["A_ub"].shape[0]):
            row, b = lp["A_ub"][i], lp["b_ub"][i]
            constraints_de.append(NonlinearConstraint(
                lambda x, r=row, b=b: b - r @ x, 0.0, np.inf))
    if lp["A_eq"].size:
        for i in range(lp["A_eq"].shape[0]):
            row, b = lp["A_eq"][i], lp["b_eq"][i]
            constraints_de.append(NonlinearConstraint(
                lambda x, r=row, b=b: r @ x - b, 0.0, 0.0))

    t0 = time.perf_counter()
    timed_out_flag = [False]

    def cb_de(xk, convergence=None):
        if time.perf_counter() - t0 > time_limit:
            timed_out_flag[0] = True
            return True

    try:
        res = differential_evolution(
            obj, de_bounds,
            constraints=constraints_de if constraints_de else (),
            maxiter=500, popsize=8, tol=1e-6,
            polish=True, seed=42, callback=cb_de, x0=ref,
        )
        success = res.success
        obj_val = float(res.fun) if success else None
        x_val   = res.x if success else None
        message = res.message
    except Exception as e:
        success, obj_val, x_val, message = False, None, None, str(e)

    return {"success": success, "obj": obj_val, "x": x_val,
            "time": time.perf_counter() - t0,
            "timed_out": timed_out_flag[0], "message": message}


def _diagnose_solver_limit(lp: dict) -> tuple[bool, str]:

    lp_res = linprog(
        c=lp["c"],
        A_ub=lp["A_ub"] if lp["A_ub"].size else None,
        b_ub=lp["b_ub"] if lp["b_ub"].size else None,
        A_eq=lp["A_eq"] if lp["A_eq"].size else None,
        b_eq=lp["b_eq"] if lp["b_eq"].size else None,
        bounds=lp["bounds"],
        method="highs",
    )
    if not lp_res.success:
        return False, ""
    reasons = []
    if lp["A_eq"].size:
        try:
            cond = np.linalg.cond(lp["A_eq"])
            if cond > _ILL_COND_THRESHOLD:
                reasons.append(f"A_eq cond={cond:.2e} (ill-conditioned, SLSQP QR singular)")
        except Exception:
            pass
    Q = lp.get("Q_obj")
    if Q is not None:
        try:
            min_eig = float(np.linalg.eigvalsh(Q).min())
            if min_eig < -1e-8:
                reasons.append(f"Q min_eig={min_eig:.4f} (non-convex, SLSQP cannot converge)")
        except Exception:
            pass
    reason_str = "; ".join(reasons) if reasons else "LP relaxation feasible but SLSQP failed (unknown cause)"
    return True, reason_str

def _solve_lp(lp: dict, time_limit: float) -> dict:
    t0  = time.perf_counter()
    res = linprog(
        c      = lp["c"],
        A_ub   = lp["A_ub"] if lp["A_ub"].size else None,
        b_ub   = lp["b_ub"] if lp["b_ub"].size else None,
        A_eq   = lp["A_eq"] if lp["A_eq"].size else None,
        b_eq   = lp["b_eq"] if lp["b_eq"].size else None,
        bounds = lp["bounds"],
        method = "highs",
        options= {"time_limit": time_limit},
    )
    msg       = getattr(res, "message", "")
    timed_out = not res.success and "time" in msg.lower()
    return {"success":   res.success,
            "obj":       float(res.fun) if res.success else None,
            "x":         res.x if res.success else None,
            "time":      time.perf_counter() - t0,
            "timed_out": timed_out, "message": msg}


def _solve_mip(lp: dict, integer_vars: List[str], time_limit: float) -> dict:
    n           = len(lp["variables"])
    int_set     = set(integer_vars)
    integrality = np.array([1.0 if lp["variables"][i] in int_set else 0.0
                             for i in range(n)])
    t0 = time.perf_counter()
    try:
        res = linprog(
            c          = lp["c"],
            A_ub       = lp["A_ub"] if lp["A_ub"].size else None,
            b_ub       = lp["b_ub"] if lp["b_ub"].size else None,
            A_eq       = lp["A_eq"] if lp["A_eq"].size else None,
            b_eq       = lp["b_eq"] if lp["b_eq"].size else None,
            bounds     = lp["bounds"],
            integrality= integrality,
            method     = "highs",
            options    = {"time_limit": time_limit},
        )
    except TypeError:
        res = linprog(
            c      = lp["c"],
            A_ub   = lp["A_ub"] if lp["A_ub"].size else None,
            b_ub   = lp["b_ub"] if lp["b_ub"].size else None,
            A_eq   = lp["A_eq"] if lp["A_eq"].size else None,
            b_eq   = lp["b_eq"] if lp["b_eq"].size else None,
            bounds = lp["bounds"],
            method = "highs",
            options= {"time_limit": time_limit},
        )
    msg       = getattr(res, "message", "")
    timed_out = not res.success and "time" in msg.lower()
    return {"success":   res.success or timed_out,
            "obj":       float(res.fun) if res.fun is not None else None,
            "x":         res.x if res.x is not None else None,
            "time":      time.perf_counter() - t0,
            "timed_out": timed_out, "message": msg}


def _solve_qp(lp: dict, time_limit: float) -> dict:
    n    = len(lp["variables"])
    Q    = lp.get("Q_obj", np.zeros((n, n)))
    c    = lp["c"]

    def obj(x):  return float(0.5 * x @ Q @ x + c @ x)
    def grad(x): return Q @ x + c

    constraints = []
    if lp["A_ub"].size:
        for i in range(lp["A_ub"].shape[0]):
            row, b = lp["A_ub"][i], lp["b_ub"][i]
            constraints.append({"type": "ineq",
                                 "fun": lambda x, r=row, b=b: b - r @ x,
                                 "jac": lambda x, r=row: -r})
    if lp["A_eq"].size:
        for i in range(lp["A_eq"].shape[0]):
            row, b = lp["A_eq"][i], lp["b_eq"][i]
            constraints.append({"type": "eq",
                                 "fun": lambda x, r=row, b=b: r @ x - b,
                                 "jac": lambda x, r=row: r})

    scipy_bounds   = [(lo if lo is not None else -np.inf,
                       hi if hi is not None else  np.inf)
                      for lo, hi in lp["bounds"]]
    deadline       = time.perf_counter() + time_limit
    timed_out_flag = [False]

    def cb(_):
        if time.perf_counter() > deadline:
            timed_out_flag[0] = True
            raise StopIteration

    t0 = time.perf_counter()
    try:
        res     = minimize(obj, np.zeros(n), jac=grad, method="SLSQP",
                           bounds=scipy_bounds, constraints=constraints,
                           callback=cb, options={"ftol": 1e-9, "maxiter": 2000})
        success = res.success
        obj_val = float(res.fun) if success else None
        x_val   = res.x if success else None
        message = res.message
    except StopIteration:
        success, obj_val, x_val, message = False, None, None, "timed out"

    if not success and not timed_out_flag[0] and _is_nonconvex_qp(lp):
        remaining = time_limit - (time.perf_counter() - t0)
        if remaining > 1.0:
            de_sol = _solve_nonconvex_qp_de(lp, remaining)
            if de_sol["success"]:
                return de_sol

    return {"success":   success, "obj": obj_val, "x": x_val,
            "time":      time.perf_counter() - t0,
            "timed_out": timed_out_flag[0], "message": message}


def _solve_minlp(lp: dict, integer_vars: List[str], time_limit: float) -> dict:
    n       = len(lp["variables"])
    int_set = set(integer_vars)
    int_idx = [i for i, v in enumerate(lp["variables"]) if v in int_set]

    Q = lp.get("Q_obj", np.zeros((n, n)))
    c = lp["c"]

    def obj(x):  return float(0.5 * x @ Q @ x + c @ x)
    def grad(x): return Q @ x + c

    scipy_bounds = [(lo if lo is not None else -np.inf,
                     hi if hi is not None else  np.inf)
                    for lo, hi in lp["bounds"]]

    def _build_constraints(fixed_int: dict | None = None):
        cons = []
        if lp["A_ub"].size:
            for i in range(lp["A_ub"].shape[0]):
                row, b = lp["A_ub"][i], lp["b_ub"][i]
                cons.append({"type": "ineq",
                              "fun": lambda x, r=row, b=b: b - r @ x,
                              "jac": lambda x, r=row: -r})
        if lp["A_eq"].size:
            for i in range(lp["A_eq"].shape[0]):
                row, b = lp["A_eq"][i], lp["b_eq"][i]
                cons.append({"type": "eq",
                              "fun": lambda x, r=row, b=b: r @ x - b,
                              "jac": lambda x, r=row: r})
        if fixed_int:
            for idx, val in fixed_int.items():
                cons.append({"type": "eq",
                              "fun": lambda x, i=idx, v=val: x[i] - v,
                              "jac": lambda x, i=idx: np.eye(n)[i]})
        return cons

    deadline = time.perf_counter() + time_limit
    t0       = time.perf_counter()

    timed_out_flag = [False]

    def cb_relax(_):
        if time.perf_counter() > deadline:
            timed_out_flag[0] = True
            raise StopIteration

    try:
        res_relax = minimize(obj, np.zeros(n), jac=grad, method="SLSQP",
                             bounds=scipy_bounds, constraints=_build_constraints(),
                             callback=cb_relax,
                             options={"ftol": 1e-9, "maxiter": 2000})
    except StopIteration:
        return {"success": False, "obj": None, "x": None,
                "time": time.perf_counter() - t0,
                "timed_out": True, "message": "timed out during relaxation"}

    if timed_out_flag[0]:
        return {"success": False, "obj": None, "x": None,
                "time": time.perf_counter() - t0,
                "timed_out": True, "message": "timed out during relaxation"}

    if not res_relax.success:
        
        try:
            lp_warm = linprog(
                c=lp["c"],
                A_ub=lp["A_ub"] if lp["A_ub"].size else None,
                b_ub=lp["b_ub"] if lp["b_ub"].size else None,
                A_eq=lp["A_eq"] if lp["A_eq"].size else None,
                b_eq=lp["b_eq"] if lp["b_eq"].size else None,
                bounds=lp["bounds"],
                method="highs",
            )
            if lp_warm.success:
                try:
                    res_relax2 = minimize(obj, lp_warm.x, jac=grad, method="SLSQP",
                                         bounds=scipy_bounds, constraints=_build_constraints(),
                                         callback=cb_relax,
                                         options={"ftol": 1e-9, "maxiter": 2000})
                    if res_relax2.success:
                        res_relax = res_relax2
                except StopIteration:
                    pass
            else:
                return {"success": False, "obj": None, "x": None,
                        "time": time.perf_counter() - t0, "timed_out": False,
                        "message": f"infeasible: LP relaxation infeasible ({lp_warm.message})"}
        except Exception:
            pass

    if not res_relax.success:
        if _is_nonconvex_qp(lp):
            remaining = time_limit - (time.perf_counter() - t0)
            if remaining > 1.0:
                de_sol = _solve_nonconvex_qp_de(lp, remaining)
                if de_sol["success"]:
                    return de_sol
        return {"success": False, "obj": None, "x": None,
                "time": time.perf_counter() - t0,
                "timed_out": False,
                "message": res_relax.message}

    x_relax = res_relax.x

    def _try_fixed(fixed_vals: dict) -> tuple[bool, float | None, np.ndarray | None, str]:
        if time.perf_counter() > deadline:
            return False, None, None, "timed out"
        to_flag = [False]
        def cb_fix(_):
            if time.perf_counter() > deadline:
                to_flag[0] = True
                raise StopIteration
        try:
            r = minimize(obj, x_relax.copy(), jac=grad, method="SLSQP",
                         bounds=scipy_bounds,
                         constraints=_build_constraints(fixed_vals),
                         callback=cb_fix,
                         options={"ftol": 1e-9, "maxiter": 1000})
            return r.success, float(r.fun) if r.success else None, r.x if r.success else None, r.message
        except StopIteration:
            return False, None, None, "timed out"

    rounded = {i: float(round(x_relax[i])) for i in int_idx}
    ok, obj_val, x_val, msg = _try_fixed(rounded)
    if ok:
        return {"success": True, "obj": obj_val, "x": x_val,
                "time": time.perf_counter() - t0,
                "timed_out": False, "message": "MINLP feasible (rounded)"}

    candidates: List[dict] = []
    floors = {i: float(np.floor(x_relax[i])) for i in int_idx}
    ceils  = {i: float(np.ceil(x_relax[i]))  for i in int_idx}

    max_enum = min(32, 2 ** len(int_idx))
    for mask in range(max_enum):
        fixed: dict = {}
        for bit, idx in enumerate(int_idx):
            fixed[idx] = ceils[idx] if (mask >> bit) & 1 else floors[idx]
        candidates.append(fixed)

    best_obj: float | None = None
    best_x:   np.ndarray | None = None
    last_msg  = msg

    for fixed in candidates:
        if time.perf_counter() > deadline:
            timed_out_flag[0] = True
            break
        ok, ov, xv, m = _try_fixed(fixed)
        if ok:
            if best_obj is None or ov < best_obj: 
                best_obj, best_x, last_msg = ov, xv, m

    if best_x is not None:
        return {"success": True, "obj": best_obj, "x": best_x,
                "time": time.perf_counter() - t0,
                "timed_out": timed_out_flag[0],
                "message": "MINLP feasible (neighbourhood search)"}

    if timed_out_flag[0]:
        return {"success": False, "obj": None, "x": None,
                "time": time.perf_counter() - t0,
                "timed_out": True, "message": "timed out during neighbourhood search"}
    return {"success": False, "obj": None, "x": None,
            "time": time.perf_counter() - t0,
            "timed_out": False,
            "message": f"No feasible integer point found near relaxation. Last: {last_msg}"}


def check_math_feasibility(problem: dict,
                            time_limit: float = DEFAULT_TIME_LIMIT) -> dict:

    result: Dict[str, Any] = {
        "status": "SOLVE_FAIL", "ptype": "?", "obj_value": None, "hint": ""}

    try:
        ptype = detect_problem_type(problem)
        result["ptype"] = ptype
    except Exception as e:
        result["status"] = "PARSE_ERROR"
        result["hint"]   = f"Type detection failed: {e}"
        return result

    try:
        lp = parse_qp(problem) if ptype in ("QP", "MINLP") else parse_lp(problem)
    except Exception as e:
        result["status"] = "PARSE_ERROR"
        result["hint"]   = f"Parse failed ({ptype}): {e}"
        return result

    try:
        if ptype == "MIP":
            sol = _solve_mip(lp, detect_integer_vars(problem), time_limit)
        elif ptype == "QP":
            sol = _solve_qp(lp, time_limit)
        elif ptype == "MINLP":
            sol = _solve_minlp(lp, detect_integer_vars(problem), time_limit)
        else:
            sol = _solve_lp(lp, time_limit)
    except Exception as e:
        result["status"] = "SOLVE_FAIL"
        result["hint"]   = f"Solver error ({ptype}): {e}"
        return result

    if sol["timed_out"] and not sol["success"]:
        result["status"] = "TIMED_OUT"
        result["hint"]   = f"Timed out (>{time_limit}s)"
        return result

    if not sol["success"]:
        msg = (sol.get("message") or "").lower()
        if "infeasible" in msg or "no feasible" in msg:
            result["status"] = "INFEASIBLE"
            result["hint"]   = f"No feasible solution: {sol.get('message', '')}"
        elif "unbounded" in msg or "dual infeasible" in msg:
            result["status"] = "UNBOUNDED"
            result["hint"]   = f"Problem unbounded: {sol.get('message', '')}"
        else:
            is_limit, limit_reason = _diagnose_solver_limit(lp)
            if is_limit:
                result["status"] = "SOLVER_LIMIT"
                result["hint"]   = f"Feasible but solver cannot handle: {limit_reason}"
            else:
                result["status"] = "SOLVE_FAIL"
                result["hint"]   = f"Solver failed: {sol.get('message') or '(no details)'}"
        return result

    sense   = lp["sense"]
    obj_val = float(sol["obj"]) * sense if sol["obj"] is not None else None
    result["obj_value"] = obj_val

    if obj_val is not None and abs(obj_val) < _ZERO_TOL:
        x = sol.get("x")
        if x is not None and np.all(np.abs(x) < _VAR_TOL):
            result["status"] = "ZERO_ONLY"
            result["hint"]   = (
                "Objective=0 and all variables=0; "
                "likely equality constraints forcing variables to zero (modeling error)")
            return result

    result["status"] = "PASS"
    return result
