from __future__ import annotations

import json
import os
import threading
import time
from itertools import count
from pathlib import Path
from typing import Any

_RUN_DIR_ENV = "DATA_GENERATION_RUN_DIR"
_LOGGER: "LLMCallLogger | None" = None
_LOGGER_LOCK = threading.Lock()


class LLMCallLogger:
    def __init__(self, default_root: str | Path, run_dir_env: str):
        self._run_dir = self._resolve_run_dir(Path(default_root), run_dir_env)
        self._run_dir.mkdir(parents=True, exist_ok=True)
        self._counter = count(1)
        self._lock = threading.Lock()

    @staticmethod
    def _resolve_run_dir(default_root: Path, run_dir_env: str) -> Path:
        existing = os.getenv(run_dir_env)
        if existing:
            return Path(existing) / "llm_calls"

        run_id = time.strftime("%Y%m%d_%H%M%S") + f"_{os.getpid()}"
        base_run_dir = default_root / run_id
        os.environ[run_dir_env] = str(base_run_dir)
        return base_run_dir / "llm_calls"

    def record_call(
        self,
        *,
        provider: str,
        model: str,
        endpoint: str,
        api_style: str,
        full_prompt: Any,
        initial_input: Any,
        response_text: str | None = None,
        error: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> Path:
        with self._lock:
            call_index = next(self._counter)

        path = self._run_dir / f"call_{call_index:04d}.json"
        payload = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "call_index": call_index,
            "provider": provider,
            "model": model,
            "endpoint": endpoint,
            "api_style": api_style,
            "full_prompt": full_prompt,
            "initial_input": initial_input,
            "response_text": response_text,
            "response_preview": (response_text or "")[:500],
            "error": error,
            "extra": extra or {},
        }
        path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2, default=str),
            encoding="utf-8",
        )
        return path


def get_llm_call_logger() -> LLMCallLogger:
    global _LOGGER
    if _LOGGER is not None:
        return _LOGGER

    with _LOGGER_LOCK:
        if _LOGGER is None:
            default_root = Path(__file__).resolve().parents[1] / "output_ob"
            _LOGGER = LLMCallLogger(default_root, _RUN_DIR_ENV)
    return _LOGGER
