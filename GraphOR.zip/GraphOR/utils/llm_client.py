
from __future__ import annotations

import os
import random
import time
from typing import Protocol

from utils.llm_call_logger import get_llm_call_logger


class BaseLLMClient(Protocol):
    def generate(self, prompt: str, system_prompt: str | None = None) -> str:
        ...


class MockLLMClient:
    def __init__(self, seed: int = 42):
        self.rng = random.Random(seed)

    def generate(self, prompt: str, system_prompt: str | None = None) -> str:
        return (
            "{"  
            "\"question\": \"Placeholder decomposable scenario focusing on cooperative scheduling.\","  
            " \"structure\": {},"
            " \"constraint_definitions\": {\"bounds\": \"all vars >= 0\"},"
            " \"objective_function\": \"minimize placeholder costs\""
            "}"
        )


class OpenAILLMClient:

    def __init__(
        self,
        model: str,
        api_key: str | None = None,
        timeout: float = 60.0,
        base_url: str | None = None,
    ):
        from openai import OpenAI

        api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise RuntimeError("OPENAI_API_KEY is not set")
        self._client = OpenAI(
            api_key=api_key, timeout=timeout, base_url=base_url)
        self._model = model
        self._base_url = base_url or ""
        self._timeout = timeout
        self._call_logger = get_llm_call_logger()

    def generate(self, prompt: str, system_prompt: str | None = None) -> str:
        response_text = None
        error_text = None
        try:
            response = self._client.responses.create(
                model=self._model,
                input=prompt,
                temperature=0.7,
            )
            response_text = response.output[0].content[0].text 
            return response_text
        except Exception as exc:
            error_text = str(exc)
            raise
        finally:
            self._call_logger.record_call(
                provider="openai",
                model=self._model,
                endpoint=self._base_url,
                api_style="responses.create",
                full_prompt={"input": prompt},
                initial_input=prompt,
                response_text=response_text,
                error=error_text,
                extra={
                    "timeout_sec": self._timeout,
                    "provided_system_prompt": system_prompt,
                    "system_prompt_sent": False,
                },
            )


class DeepSeekLLMClient:
    def __init__(
        self,
        model: str,
        api_key: str,
        timeout: float = 80.0,
        base_url: str | None = None,
    ):
        if not api_key:
            raise RuntimeError("DeepSeek API key is required")
        from openai import OpenAI

        self._client = OpenAI(
            api_key=api_key,
            base_url=base_url or "https://api.deepseek.com",
            timeout=timeout
        )
        self._model = model
        self._base_url = base_url or "https://api.deepseek.com"
        self._timeout = timeout
        self._call_logger = get_llm_call_logger()

    def generate(self, prompt: str, system_prompt: str | None = None) -> str:
        system = system_prompt or "You are a helpful assistant"
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": prompt},
        ]
        response_text = None
        error_text = None
        try:
            response = self._client.chat.completions.create(
                model=self._model,
                messages=messages,
                stream=False,
                temperature=0.7,
            )
            response_text = response.choices[0].message.content
            return response_text
        except Exception as exc:
            error_text = str(exc)
            raise
        finally:
            self._call_logger.record_call(
                provider="deepseek_compatible",
                model=self._model,
                endpoint=self._base_url,
                api_style="chat.completions",
                full_prompt=messages,
                initial_input=prompt,
                response_text=response_text,
                error=error_text,
                extra={"timeout_sec": self._timeout},
            )


def create_llm_client(
    backend: str | None,
    model: str | None,
    api_key: str | None,
    timeout: float = 60.0,
    base_url: str | None = None,
) -> BaseLLMClient:
    backend = (backend or "mock").lower()
    if backend == "mock":
        return MockLLMClient()
    if backend == "openai":
        if not model:
            raise ValueError("OpenAI backend requires a model name")
        return OpenAILLMClient(model=model, api_key=api_key, timeout=timeout, base_url=base_url)
    if backend == "deepseek":
        if not model:
            raise ValueError("DeepSeek backend requires a model name")
        if not api_key:
            raise ValueError("DeepSeek backend requires an API key")
        return DeepSeekLLMClient(model=model, api_key=api_key, timeout=timeout, base_url=base_url)
    raise ValueError(f"Unsupported LLM backend: {backend}")


class RetryLLMClient:

    def __init__(self, inner: BaseLLMClient, name: str, retries: int = 3, backoff_sec: float = 1.0):
        self.inner = inner
        self.name = name
        self.retries = max(0, retries)
        self.backoff_sec = max(0.0, backoff_sec)

    def generate(self, prompt: str, system_prompt: str | None = None) -> str:
        attempt = 0
        last_exc: Exception | None = None
        while attempt <= self.retries:
            attempt += 1
            started = time.perf_counter()
            print(f"[llm] {self.name} attempt {attempt}/{self.retries + 1}")
            try:
                result = self.inner.generate(
                    prompt, system_prompt=system_prompt)
                elapsed = time.perf_counter() - started
                print(f"[llm] {self.name} success in {elapsed:.2f}s")
                return result
            except Exception as exc:  
                elapsed = time.perf_counter() - started
                print(f"[llm] {self.name} failed in {elapsed:.2f}s: {exc}")
                last_exc = exc
                if attempt <= self.retries and self.backoff_sec:
                    time.sleep(self.backoff_sec * attempt)
        raise RuntimeError(
            f"LLM call failed after {self.retries + 1} attempts: {last_exc}")


class FallbackLLMClient:
    def __init__(self, clients: list[BaseLLMClient], name: str):
        if not clients:
            raise ValueError("FallbackLLMClient requires at least one client")
        self.clients = clients
        self.name = name

    def generate(self, prompt: str, system_prompt: str | None = None) -> str:
        last_exc: Exception | None = None
        for idx, client in enumerate(self.clients, start=1):
            if idx > 1:
                print(
                    f"[llm] {self.name} switching to backup key {idx}/{len(self.clients)}")
            try:
                return client.generate(prompt, system_prompt=system_prompt)
            except Exception as exc: 
                last_exc = exc
                continue
        raise RuntimeError(f"LLM call failed for all keys: {last_exc}")
