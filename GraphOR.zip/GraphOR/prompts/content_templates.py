
from textwrap import dedent


MATHEMATICAL_BRIEF_TEMPLATE = dedent(
    """
    You are provided with a structural blueprint for a decomposable optimization problem.
    Produce ONLY a JSON object with the keys `structure`, `constraint_definitions`, and `objective_function`. Do not include natural-language narrative or any additional fields. Follow the workflow:
    1. **Structure fidelity** — copy the blueprint verbatim into the `structure` field (same arrays, graphs, metadata). Do NOT invent or rename variables, constraints, or graph edges. If a value is missing in your reasoning, reuse the blueprint entry instead of hallucinating.
    2. **Problem type selection** — You may generate LP, MILP, QP, or MINLP problems:
       - LP: linear objective + linear constraints, continuous variables
       - MILP: linear objective + linear constraints, some integer/binary variables
       - QP: quadratic objective + linear constraints, continuous variables
       - MINLP: quadratic objective + linear constraints, some integer/binary variables
       Choose based on the problem domain. For MILP/MINLP, include "integer_variables" list in structure.
    3. **constraint equations** — for every constraint in the blueprint, emit one algebraic expression referencing exactly the variables listed in that constraint's incidence set. No constraint may have an empty or mismatched variable list. You MUST add a "bounds" constraint to state variable domains.
    4. **Objective** — create a textual objective that begins with "minimize" or "maximize" and includes every objective variable at least once with concrete numeric coefficients.

    Output template (MUST match exactly): {{"structure": {{...}}, "constraint_definitions": {{...}}, "objective_function": "..."}}
    Strict serialization requirements (violations make the run fail immediately):
    - Respond with EXACTLY one JSON object. No markdown code fences, no prose before/after, no trailing explanations.
    - Use double quotes for every string and ensure the output could be parsed by `json.loads` without post-processing.
    - Keep the top-level schema as `{{ "structure": {{...}}, "constraint_definitions": {{...}}, "objective_function": "..." }}` and do not add or remove keys.

    Validation rules:
    - Variable, constraint, and graph names must match the blueprint exactly.
    - Numerical coefficients must be explicit numbers (integers or decimals). Avoid placeholders such as "alpha" or "c".
    - Do not introduce new identifiers or omit any blueprint constraint/variable.
    - For MILP/MINLP problems: specify integer variables in bounds using "integer" keyword or "in {{0,1}}" for binary, AND include "integer_variables" array in structure.
    - For QP/MINLP problems: use quadratic terms in objective (e.g., "x1^2" or "x1*x2").
    - The JSON must be valid and contain NO commentary or extra keys.

    Example LP output:
    {{"structure": {{"variables": ["x1", "x2"], "constraints": ["c1", "c2"], "variable_constraint_graph": {{"c1": ["x1", "x2"], "c2": ["x2"]}}, "problem_type": "LP"}}, "constraint_definitions": {{"c1": "3*x1 + 2*x2 <= 40", "c2": "1*x2 >= 5", "bounds": "x1, x2 >= 0"}}, "objective_function": "minimize 5*x1 + 4*x2"}}

    Example MILP output:
    {{"structure": {{"variables": ["y1", "y2", "x1"], "constraints": ["c1", "c2"], "variable_constraint_graph": {{"c1": ["y1", "y2", "x1"], "c2": ["x1"]}}, "problem_type": "MILP", "integer_variables": ["y1", "y2"]}}, "constraint_definitions": {{"c1": "10*y1 + 15*y2 + 2*x1 <= 50", "c2": "x1 >= 3", "bounds": "y1, y2 in {{0,1}}; x1 >= 0"}}, "objective_function": "minimize 100*y1 + 150*y2 + 5*x1"}}

    Example QP output:
    {{"structure": {{"variables": ["x1", "x2"], "constraints": ["c1", "c2"], "variable_constraint_graph": {{"c1": ["x1", "x2"], "c2": ["x2"]}}, "problem_type": "QP"}}, "constraint_definitions": {{"c1": "3*x1 + 2*x2 <= 40", "c2": "x2 >= 5", "bounds": "x1, x2 >= 0"}}, "objective_function": "minimize x1^2 + 2*x1*x2 + x2^2 + 5*x1 + 4*x2"}}

    Example MINLP output:
    {{"structure": {{"variables": ["y1", "x1", "x2"], "constraints": ["c1", "c2"], "variable_constraint_graph": {{"c1": ["y1", "x1", "x2"], "c2": ["x1", "x2"]}}, "problem_type": "MINLP", "integer_variables": ["y1"]}}, "constraint_definitions": {{"c1": "10*y1 + x1 + x2 <= 50", "c2": "x1 + 2*x2 >= 10", "bounds": "y1 in {{0,1}}; x1, x2 >= 0"}}, "objective_function": "minimize 100*y1 + x1^2 + x2^2 + 3*x1*x2"}}

    Blueprint summary:
    {blueprint_summary}
    """
)


QUESTION_BRIEF_TEMPLATE = dedent(
    """
        You are writing the polished, scenario-rich statement for an optimization problem whose mathematical model is already fixed.
        Inputs:
        - Blueprint summary:
        {blueprint_summary}
        - constraints:
        {constraint_summary}
        - Objective:
        {objective_summary}
        - Scenario instructions (may be a seed narrative to draw inspiration from, OR a
          [FREE GENERATION MODE] / [CONTRAST GENERATION MODE] directive — follow the
          mode tag exactly if present; otherwise treat the text as narrative inspiration):
        {seed_context}

        Feedback from earlier attempts:
        {feedback_block}

        Respond with EXACTLY one JSON object that matches this schema:
        {{
            "scenario": "2-3 sentences describing the real-world background and domain hint",
            "question": "1-2 paragraphs that reference every variable/constraint explicitly and explain the optimization goal",
            "coverage": {{
                "variables": ["list every decision variable exactly once"],
                "constraints": ["list every constraint name exactly once"],
                "objective": "Summarize whether we minimize or maximize and what the cost/benefit represents"
            }}
        }}

        Requirements:
        - Follow the scenario instructions above strictly: if a mode tag ([FREE GENERATION MODE] or [CONTRAST GENERATION MODE]) is present, obey it; otherwise draw inspiration from the seed narrative while fitting the domain hint.
        - In `question`, explain how each constraint family governs the resources/flows mentioned in the scenario, and call out coupling or shared-capacity relationships.
        - Never introduce new variables/constraints; reuse the exact names from the blueprint when narrating decisions and limits.
        - Ensure `coverage.variables` and `coverage.constraints` include every name from the blueprint with no omissions or extras (order can follow the blueprint).
        - Use professional prose (no bullet lists, markdown, or equations) but make the relationships traceable so a reader could rebuild the model.

        Example output:
        {{
            "scenario": "Regional planners coordinate ore and clinker movements across three districts that share rail corridors and storage depots.",
            "question": "Planners choose shipment levels xA1, xA2, and xB1 so each plant balance constraint c1–c3 is honored while coupling constraint c4 caps shared rail usage. Describe the logistics narrative and request the optimizer to minimize the stated transport and handling costs.",
            "coverage": {{
                "variables": ["xA1", "xA2", "xB1"],
                "constraints": ["c1", "c2", "c3", "c4"],
                "objective": "minimize transport + handling"
            }}
        }}

        Strict serialization rules:
        - Output only the JSON object above (double quotes, no markdown fences, no commentary).
        - All strings must be valid UTF-8 text parsable via `json.loads` without cleanup.
        - If feedback is provided, incorporate it verbatim while regenerating the scenario/question.
        """
)


def format_blueprint_summary(blueprint: dict) -> str:
    parts = [
        f"Problem name: {blueprint.get('name', 'unnamed')}",
        f"Problem type: {blueprint.get('problem_type', 'LP')}",
        f"Domain hint: {blueprint.get('domain_hint', 'general operations research')}",
        f"Variables ({len(blueprint.get('variables', []))}): {blueprint.get('variables', [])}",
        f"constraints ({len(blueprint.get('constraints', []))}): {blueprint.get('constraints', [])}",
        "Variable-constraint incidence:"
    ]
    for constraint, vars_in_c in blueprint.get('variable_constraint_graph', {}).items():
        parts.append(f"  - {constraint}: {vars_in_c}")


    int_vars = blueprint.get('integer_variables', [])
    if int_vars:
        parts.append(f"Integer variables: {int_vars}")

    if blueprint.get('decomposition'):
        parts.append(f"Decomposition guidance: {blueprint['decomposition']}")
    return "\n".join(parts)


def format_constraint_summary(constraints: dict | None) -> str:
    if not constraints:
        return "  (no constraints provided)"
    lines = []
    for name, expr in constraints.items():
        lines.append(f"  - {name}: {expr}")
    return "\n".join(lines)
